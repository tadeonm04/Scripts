import pandas as pd
from google.cloud import bigquery
from google.oauth2 import service_account
import requests
import traceback
from langdetect import detect
import random
from string import ascii_letters
from deep_translator import GoogleTranslator
import os
import difflib
from difflib import SequenceMatcher
import re
import json
import string
import numpy as np
import spacy
import logging
from typing import Any, Hashable, Iterable, Optional
# Categorizador
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
import hdbscan
# from transformers import pipeline
# import torch
from openai import OpenAI
# Cargar el modelo de spaCy
# -----------------------------------------------------------------------------
# Actores
# -----------------------------------------------------------------------------
# Actores FB
from Facebook.FacebookActors import FacePostScraper
from Facebook.FacebookActors import FaceCommentScraper
from Facebook.FacebookActors import FaceHashtagScraper
# Actores Instagram
from Instagram.InstagramActors import InstaHashtagScraper
from Instagram.InstagramActors import InstaPostScraper
from Instagram.InstagramActors import InstaCommentScraper
# Actores Tiktok
from Tiktok.TiktokActors import TiktokHashtagScraper
from Tiktok.TiktokActors import TitkokCommentScraper
from Tiktok.TiktokActors import TiktokProfileScraper
from Tiktok.TiktokActors import TiktokSearchScraper
# Actores Linkedin
from Linkedin.LinkedinSearch import ScrapLinkedinSearchProfilesLinks
from Linkedin.LinkedinSearch import ScrapLinkedinComments
# Actores Youtube
# from Youtube.YoutubeActors import YoutubeScraper
from datetime import datetime, timedelta
import time 


nlp = spacy.load('es_core_news_sm')


def CargaDatosBigquery(user_name,
                       fechahoy,
                       execution_time,
                       nombre_proyecto,
                       start_urlsFB,
                       urlprofilestinsta,
                       start_urlsTT,
                       hashtagfb,
                       hashtaginsta,
                       hashtagtiktok,
                       urlsearchtitkok):
    '''
    Funcion de carga de datos a una tabla de BigQuery de google

    Parameters
    ----------
    user_name : TYPE
        DESCRIPTION.
    fechahoy : TYPE
        DESCRIPTION.
    execution_time : TYPE
        DESCRIPTION.
    nombre_proyecto : TYPE
        DESCRIPTION.
    start_urlsFB : TYPE
        DESCRIPTION.
    urlprofilestinsta : TYPE
        DESCRIPTION.
    start_urlsTT : TYPE
        DESCRIPTION.
    hashtagfb : TYPE
        DESCRIPTION.
    hashtaginsta : TYPE
        DESCRIPTION.
    hashtagtiktok : TYPE
        DESCRIPTION.
    urlsearchtitkok : TYPE
        DESCRIPTION.

    Returns
    -------
    respuesta : TYPE
        DESCRIPTION.

    '''
    try:
        # ##Proceso de creacion DF #################
        data = {'fecha_ejecucion': fechahoy,
                'usuario': user_name,
                'tiempo_ejecucion': execution_time,
                'nombre_proyecto': nombre_proyecto,
                'urlprofilesfb': start_urlsFB,
                'urlprofilesig': urlprofilestinsta,
                'urlprofilestiktok': start_urlsTT,
                'hashtagfb': hashtagfb,
                'hashtagig': hashtaginsta,
                'hashtagtiktok': hashtagtiktok,
                'searchtiktok': urlsearchtitkok
                }
        # Crear DataFrame con una sola fila
        df = pd.DataFrame([data])
        # ---------------------------------------------------------------------
        # Creacion del archivo temporal para cargar en BigQuery
        # ---------------------------------------------------------------------
        upload_file_name = 'upload_boletin.csv'
        result_file_path = os.path.join(os.getcwd(), upload_file_name)
        df.to_csv(result_file_path, index=False)
        # ---------------------------------------------------------------------
        # Integración de datos a Bigquery
        # ---------------------------------------------------------------------
        project_id = 'beker-socialand'
        dataset_id = 'ApifyApp'
        table_id = 'RegistrosApify'

        print('Inicio de carga de datos en BigQuery')
        # ---------------------------------------------------------------------
        # Configura las credenciales del servicio
        # ---------------------------------------------------------------------
        credentials = service_account.Credentials.from_service_account_file('beker-socialand-425907de0ba6.json')
        # ---------------------------------------------------------------------
        # Crear un cliente de BigQuery
        # ---------------------------------------------------------------------
        client = bigquery.Client(credentials=credentials, project=project_id)

        # # Define el ID de la tabla completa
        table_ref = f'{project_id}.{dataset_id}.{table_id}'

        try:
            # -----------------------------------------------------------------
            # Check if output table exists and get its schema
            # -----------------------------------------------------------------
            schema = client.get_table(table_ref).schema
        except Exception:
            # -----------------------------------------------------------------
            # Create output table if it doesn't exist and get its schema
            # -----------------------------------------------------------------
            schema = [
                bigquery.SchemaField('Fecha', 'STRING'),
                bigquery.SchemaField('Tipo de Norma', 'STRING'),
                bigquery.SchemaField('Firmante', 'STRING'),
                bigquery.SchemaField('Norma', 'STRING'),
                bigquery.SchemaField('Texto', 'STRING'),
                bigquery.SchemaField('Link', 'STRING'),
            ]
            table = bigquery.Table(table_ref, schema=schema)
            table = client.create_table(table, timeout=10)

        job_config = bigquery.LoadJobConfig(source_format=bigquery.SourceFormat.CSV,
                                            skip_leading_rows=1,
                                            schema=schema)

        with open(result_file_path, 'rb') as source_file:
            job = client.load_table_from_file(source_file,
                                              table_ref,
                                              job_config=job_config)
        job.result()
        respuesta = 'Datos Cargados Correctamente'
        return respuesta
    except Exception as e:
        print(e)
        # ---------------------------------------------------------------------
        # columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes',
        #               'Tipo de Mencion', 'Numero de Comentarios']
        # df = pd.DataFrame(columns=columnlist)
        # ---------------------------------------------------------------------
        traceback.print_exc()
        respuesta = 'Error en la Carga de Datos a BigQuery'
        return respuesta


def process_chunk(chunk):
    try:
        lang = 'es'
        data = {
            "language": lang,
            "urls": chunk['Link_random'].tolist(),
            'tweets': chunk['text'].tolist(),
            'target_entities': chunk['Target Entities'].tolist()
        }
        # ---------------------------------------------------------------------
        # Enviar solicitud para análisis de sentimiento
        # ---------------------------------------------------------------------
        r = requests.post("https://gea.llyc.app/gea2/", json=data, timeout=500)
        if r.status_code == 200:
            print('Inferencia terminada para un chunk!')
            response_json = r.json()
            chunk['clean_text'] = response_json['tweets']
            chunk['GEA_sentiment_score'] = response_json['preds']
            chunk['GEA_sentiment_str'] = chunk['GEA_sentiment_score'].replace({1: 'positive', -1: 'negative', 0: 'neutral'})
        else:
            raise Exception(r.text)
    except Exception as e:
        print(e)
    return chunk


def ProcesamientoChunkGea(Dfinaltotal):
    # -------------------------------------------------------------------------
    # Inicializar columna de entidades objetivo
    # -------------------------------------------------------------------------
    Dfinaltotal['Target Entities'] = ''
    # -------------------------------------------------------------------------
    # Convertir columnas a string
    # -------------------------------------------------------------------------
    Dfinaltotal['Link'] = Dfinaltotal['Link'].astype(str)
    Dfinaltotal['text'] = Dfinaltotal['text'].astype(str)
    # -------------------------------------------------------------------------
    # Limpiar texto y generar identificador aleatorio
    # -------------------------------------------------------------------------
    Dfinaltotal['text'] = Dfinaltotal['text'].str.replace(r'(|\d+\.)', '').str.split().agg(" ".join)
    Dfinaltotal['random'] = [''.join(random.choice(ascii_letters) for _ in range(10)) for _ in range(len(Dfinaltotal))]
    Dfinaltotal['Link_random'] = Dfinaltotal.Link.str.cat(Dfinaltotal.random)
    # -------------------------------------------------------------------------
    # Dividir el DataFrame en chunks si excede las 5000 filas
    # -------------------------------------------------------------------------
    chunk_size = 5000
    try:
        if len(Dfinaltotal) > chunk_size:
            chunks = [Dfinaltotal[i:i + chunk_size] for i in range(0, len(Dfinaltotal), chunk_size)]
            processed_chunks = [process_chunk(chunk) for chunk in chunks]
            Dfinaltotal = pd.concat(processed_chunks)
        else:
            Dfinaltotal = process_chunk(Dfinaltotal)
    except Exception as e:
        print(e)
        traceback.print_exc()
    return Dfinaltotal


def TraduccionFiltrado(df):
    print('Ejecutando Filtrado y Traducciónv2')
    try:
        def detect_language(text):
            try:
                leng=detect(text)
                return leng
            except Exception:
                return 'unknown'
        df['Lenguaje'] = df['text'].apply(detect_language)
        valores_permitidos = ['es', 'en', 'pt']
        # ---------------------------------------------------------------------
        # Filtrar el DataFrame
        # ---------------------------------------------------------------------
        df = df[df['Lenguaje'].isin(valores_permitidos)]
        # ---------------------------------------------------------------------
        # Función para traducir el texto basado en el idioma
        # ---------------------------------------------------------------------

        def traducir_si_no_es(texto, idioma):
            if len(texto) < 5000:
                if idioma == 'en':
                    translator = GoogleTranslator(source='en', target='es')
                elif idioma == 'pt':
                    translator = GoogleTranslator(source='pt', target='es')
                else:
                    # ---------------------------------------------------------
                    # No traducir si el idioma es 'es' o no está definido
                    # ---------------------------------------------------------
                    return texto

                return translator.translate(texto)
            return texto

        df = df.rename(columns={'text': 'text_original'})
        # ---------------------------------------------------------------------
        # Aplicar la traducción
        # ---------------------------------------------------------------------
        df['text'] = df.apply(lambda row: traducir_si_no_es(row['text_original'], row['Lenguaje']), axis=1)
        return df
    except Exception as e:
        print(e)
        # columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes',
        #               'Tipo de Mencion', 'Numero de Comentarios']
        # df = pd.DataFrame(columns=columnlist)
        print('Error en traductor')
        traceback.print_exc()
        return df

def Categorizador(df,
                  dict_catego,
                  col_input='clean_text',
                  col_output='Categoria',
                  threshold = 0.75):
    try:
        # ---------------------------------------------------------------------
        # Diccionario de palabras clave y sus categorías
        # Nombre del archivo JSON que vamos a leer
        # nombre_archivo = 'categorias_ucb_dravet.json'
        # palabras = json.dumps(dict_catego)
        # ---------------------------------------------------------------------
        palabras_clave = dict_catego
        # Leer el archivo JSON y convertirlo en un diccionario
        # with open(nombre_archivo, 'r', encoding='utf-8') as archivo_json:
        #     palabras_clave = json.load(archivo_json)
        # ---------------------------------------------------------------------
        # Imprimir el diccionario para verificar
        # ---------------------------------------------------------------------
        # print(palabras_clave)
        # ---------------------------------------------------------------------
        # Función para limpiar texto (ya proporcionada)
        # ---------------------------------------------------------------------

        def limpiar_texto(texto):
            if pd.isna(texto):
                return ''
            texto_str = str(texto)
            texto_sin_puntuacion = re.sub(r'[{}]'.format(string.punctuation),
                                          '',
                                          texto_str)
            texto_limpio = texto_sin_puntuacion.lower()
            return texto_limpio
        # ---------------------------------------------------------------------
        # Función para obtener similitud de strings (ya proporcionada)
        # ---------------------------------------------------------------------

        def get_diff(row, word):
            if isinstance(row[col_input], str):
                li = list(row[col_input].split(" "))
                words_similares = difflib.get_close_matches(word,
                                                            li,
                                                            cutoff=0.975)
                if words_similares:
                    for palabra in words_similares:
                        parentezco = SequenceMatcher(None,
                                                     palabra,
                                                     word).ratio()
                    return parentezco
                else:
                    # ---------------------------------------------------------
                    # Devolver 0.0 en lugar de una cadena vacía
                    # ---------------------------------------------------------
                    return 0.0
            else:
                # -------------------------------------------------------------
                # Devolver 0.0 en lugar de una cadena vacía
                # -------------------------------------------------------------
                return 0.0
        # --------------------------------------------------------------
        # Limpiar y vectorizar las palabras clave
        # --------------------------------------------------------------

        def limpiar_y_vectorizar_palabras_clave(palabras_clave):
            palabras_clave_vectores = {}
            for categoria, palabras in palabras_clave.items():
                vectores = []
                palabras_limpias = [limpiar_texto(palabra) for palabra in palabras]
                for palabra_limpia in palabras_limpias:
                    vector = nlp(palabra_limpia).vector
                    # ---------------------------------------------------------
                    # Asegurarse de que el vector no este vacio
                    # ---------------------------------------------------------
                    if np.linalg.norm(vector) > 0:
                        vectores.append((palabra_limpia, vector))
                    else:
                        print(f"Palabra clave sin vector: {palabra_limpia}")
                        # -----------------------------------------------------
                        # Agregar como None para comprobar string similarity
                        # -----------------------------------------------------
                        vectores.append((palabra_limpia, None))
                palabras_clave_vectores[categoria] = vectores
            return palabras_clave_vectores
        palabras_clave_vectores = limpiar_y_vectorizar_palabras_clave(palabras_clave)
        df[col_input] = df[col_input].apply(limpiar_texto)
        # ---------------------------------------------------------------------
        # Función para clasificar basándose en similitud de vectores o strings
        # ---------------------------------------------------------------------

        def clasificar_texto(row):
            categorias_detectadas = []
            palabras = row[col_input].split()
            for palabra in palabras:
                doc = nlp(palabra)
                if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
                    print(f"Palabra sin vector: {palabra}")
                    continue
                for categoria, vectores in palabras_clave_vectores.items():
                    for palabra_clave, palabra_vector in vectores:
                        if palabra_vector is not None:
                            similitud = np.dot(doc.vector, palabra_vector) / (np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector))
                            # -------------------------------------------------
                            # Umbral de similitud, ajustable
                            # -------------------------------------------------
                            if similitud > threshold:
                                categorias_detectadas.append(categoria)
                                # ---------------------------------------------
                                # Evitar Duplicados
                                # ---------------------------------------------
                                break
                        else:
                            # -------------------------------------------------
                            # Umbral de similitud de Strings, ajustable
                            # -------------------------------------------------
                            if get_diff(row, palabra_clave) > threshold:
                                categorias_detectadas.append(categoria)
                                # ---------------------------------------------
                                # Evistar Duplicados
                                # ---------------------------------------------
                                break
            return ", ".join(set(categorias_detectadas)) if categorias_detectadas else "No Match"
        # Aplicar la clasificación
        df[col_output] = df.apply(clasificar_texto, axis=1)
        return df
    except Exception as e:
        print(e)
        print('Error en proceso categorizador')
        traceback.print_exc()
        return df




def log(message):
    logging.info(message)
    print(message)


def crear_diccionario(categorias, subcategorias_inputs):
    diccionario = {}
    for categoria, subcategorias_text in zip(categorias, subcategorias_inputs):
        # ---------------------------------------------------------------------
        # Convertir la cadena de texto en una lista de subcategorías
        # ---------------------------------------------------------------------
        subcategorias_lista = [subcategoria.strip() for subcategoria in subcategorias_text.split(',') if subcategoria.strip()]
        diccionario[categoria] = subcategorias_lista
    return diccionario
# -----------------------------------------------------------------------------
# Función para mostrar el diccionario (puede ser reemplazada por otro proceso)
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# Función para limpiar texto (ya proporcionada)
# -----------------------------------------------------------------------------


def limpiar_texto(texto):
    if pd.isna(texto):
        return ''
    texto_str = str(texto)
    texto_sin_puntuacion = re.sub(r'[{}]'.format(string.punctuation),
                                  '',
                                  texto_str)
    texto_limpio = texto_sin_puntuacion.lower()
    return texto_limpio
# --------------------------------------------------------------
# Función para obtener similitud de strings (ya proporcionada)
# --------------------------------------------------------------


def get_diff(row, word):
    if isinstance(row['clean_text'], str):
        li = list(row['clean_text'].split(" "))
        words_similares = difflib.get_close_matches(word, li, cutoff=0.975)
        if words_similares:
            for palabra in words_similares:
                parentezco = SequenceMatcher(None, palabra, word).ratio()
            return parentezco
        else:
            return 0.0  # Devolver 0.0 en lugar de una cadena vacía
    else:
        return 0.0  # Devolver 0.0 en lugar de una cadena vacía
# --------------------------------------------------------------
# Limpiar y vectorizar las palabras clave
# --------------------------------------------------------------


def limpiar_y_vectorizar_palabras_clave(palabras_clave):
    palabras_clave_vectores = {}
    for categoria, palabras in palabras_clave.items():
        vectores = []
        palabras_limpias = [limpiar_texto(palabra) for palabra in palabras]
        for palabra_limpia in palabras_limpias:
            vector = nlp(palabra_limpia).vector
            # -----------------------------------------------------------------
            # Asegurarse que el vector no este vacio
            # -----------------------------------------------------------------
            if np.linalg.norm(vector) > 0:
                vectores.append((palabra_limpia, vector))
            else:
                log(f"Palabra clave sin vector: {palabra_limpia}")
                # --------------------------------------------------------------
                # agregar como None para comprobar el strin similatiry
                # --------------------------------------------------------------
                vectores.append((palabra_limpia, None))
        palabras_clave_vectores[categoria] = vectores
    return palabras_clave_vectores


def extraer_fecha(columna):
    # -------------------------------------------------------------------------
    # Inicializamos una lista vacía para almacenar las fechas extraídas
    # -------------------------------------------------------------------------
    date = []
    # -------------------------------------------------------------------------
    # Iteramos sobre cada elemento de la columna
    # -------------------------------------------------------------------------
    for d in columna:
        # ---------------------------------------------------------------------
        # Convertimos el elemento a string y separamos por 'T',
        # tomando solo la parte de la fecha (el primer elemento)
        # ---------------------------------------------------------------------
        f = str(d).split('T')[0]
        # ---------------------------------------------------------------------
        # Añadimos la fecha extraída a la lista
        # ---------------------------------------------------------------------
        date.append(f)
    # Devolvemos la lista con las fechas extraídas
    return date
# -----------------------------------------------------------------------------
# Preparar datos para la solicitud
# -----------------------------------------------------------------------------


def buscar_dicc(it: Iterable[dict],
                clave: Hashable,
                valor: Any) -> Optional[dict]:
    for dicc in it:
        if dicc[clave] == valor:
            return dicc
    return None


def extraer_competencia_fb(columna):
    compet = []
    for r in columna:
        if pd.isna(r):
            # -----------------------------------------------------------------
            # Manejar el caso Nan Asignando None
            # -----------------------------------------------------------------
            c = None
        else:
            try:
                c = r.split('www.facebook.com/')[1].split('/')[0]
            # -----------------------------------------------------------------
            # En caso de que la URL n otenga el formato esperado
            # -----------------------------------------------------------------
            except IndexError:
                # -------------------------------------------------------------
                # Asignar None si la URL no se puede procesar
                # -------------------------------------------------------------
                c = None
            except AttributeError:
                c = None
                print("AttributeError")
        compet.append(c)
    return compet


def extraer_competencia_tt(columna):
    compet = []
    for r in columna:
        try:
            c = str(r).split('@')[1].split('/')[0]
        # ---------------------------------------------------------------------
        # En caso de que la URNL no tenga el formato esperado
        # ---------------------------------------------------------------------
        except IndexError:
            # ---------------------------------------------------------------------
            # Asignar None si la URL no se puede procesar
            # ---------------------------------------------------------------------
            c = None
        compet.append(c)
    return compet

# -----------------------------------------------------------------------------
# UTILS GPU (INICIO)
# -----------------------------------------------------------------------------


# def summarize_cluster(cluster_texts):
#     device = 0 if torch.cuda.is_available() else -1
#     if len(cluster_texts) == 0:
#         return "Grupo sin contenido"
#     # -----------------------------------------------------------------------
#     # Especificar el uso de la GPU
#     # -----------------------------------------------------------------------
#     summarizer = pipeline('summarization',
#                           model="facebook/bart-large-cnn",
#                           device=device)
#     combined_text = ' '.join(cluster_texts)
#     try:
#         summary = summarizer(combined_text,
#                              max_length=5000,
#                              min_length=10,
#                              do_sample=False)[0]['summary_text']
#     except IndexError:
#         summary = combined_text[:50]
#     return summary

# def Categorizador_NS(df,min_cluster=2,max_cluster=15):
#     try:
#         df['processed_text'] = df['clean_text'].apply(preprocess_text)
#         tfidf_vectorizer = TfidfVectorizer(max_features=100000000)
#         X_tfidf = tfidf_vectorizer.fit_transform(df['processed_text'])

#         # sentences = [text.split() for text in df['processed_text']]
#         # w2v_model = Word2Vec(sentences,
#         #                      vector_size=1000,
#         #                      window=50,
#         #                      min_count=2,
#         #                      workers=5)
#         # X_w2v = np.array([np.mean([w2v_model.wv[word] for word in sentence if word in w2v_model.wv]or [np.zeros(1000)], axis=0)for sentence in sentences])
#         # pca = PCA(n_components=500, random_state=42)

#         pca = PCA(random_state=42)
#         X_reduced = pca.fit_transform(X_tfidf.toarray())  # O usar X_w2v
#         hdbscan_clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster,
#                                             max_cluster_size=max_cluster,
#                                             metric='euclidean',
#                                             cluster_selection_method='eom')
#         df['cluster'] = hdbscan_clusterer.fit_predict(X_reduced)
#         cluster_names = {}
#         for cluster_num in df['cluster'].unique():
#             cluster_texts = df[df['cluster'] == cluster_num]['processed_text'].tolist()
#             cluster_names[cluster_num] = summarize_cluster(cluster_texts)
#         df['cluster_name'] = df['cluster'].map(cluster_names)

#         for i in cluster_names.keys():
#             cluster_names[i] = cluster_names[i].strip()
#         return df, cluster_names
#     except ValueError as e:
#         print("error")
#         print(e)
#         return df

# -----------------------------------------------------------------------------
# UTILS GPU (FIN)
# -----------------------------------------------------------------------------


def preprocess_text_nlp(text):
    if not isinstance(text, str) or not text.strip():
        # Si el texto no es una cadena o está vacío, devuelve una cadena vacía
        return ""
    # Eliminar URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    # Eliminar menciones y hashtags
    text = re.sub(r'\@\w+|\#', '', text)
    # Eliminar emojis y caracteres no alfabéticos
    text = re.sub(r'[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]', '', text)
    # Eliminar números
    text = re.sub(r'\d+', '', text)
    # Convertir a minúsculas
    text = text.lower()
    # Procesar con spaCy
    doc = nlp(text)
    # Lematización, eliminando stop words y puntuación
    tokens = [token.lemma_ for token in doc
              if not token.is_stop and not token.is_punct]
    # Unir los tokens en un solo string
    processed_text = ' '.join(tokens)
    # Eliminar espacios en blanco adicionales
    processed_text = re.sub(r'\s+', ' ', processed_text).strip()
    return processed_text


def preprocess_text(text):
    if not isinstance(text, str) or not text.strip():
        return ""
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    text = re.sub(r'\@\w+|\#', '', text)
    text = re.sub(r'[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]', '', text)
    processed_text = re.sub(r'\s+', ' ', text).strip()
    return processed_text


def Categorizador_NS_GPT(df,
                         min_cluster_size=10,
                         min_cluster='uno',
                         max_cluster='tres') -> pd.core.frame.DataFrame:
    '''
    Recibe un Dataframe con una columna llamada clean_text, para realizar una
    clasificacion no supervisada, utilizando el algoritmo
    HDBSCAN de sklearn, el tamaño de clusters dependera de la cantidad minima
    de elementos por cluster, dada por la variable  min_cluster_size,
    la agrupacion de clusters se da mediante chat gpt, y la cantidad minima y
    maxima esta dada por las vairables min_cluster y  max_cluster
    respectivamente

    Parameters
    ----------
    df : pandas.core.frame.DataFrame
        DESCRIPTION.
    min_cluster_size : Int, optional
        DESCRIPTION. Tamaño minimo de elementos por cluster.
        El valor por default es  10.
    min_cluster : str, optional
        DESCRIPTION. Cantidad minima de agrupacion de clusters, dado en str.
        El valor por default es 'uno'.
    max_cluster : str, optional
        DESCRIPTION. Cantidad Maxima de agrupacion de clusters, dado en str.
        El valor por default es 'tres'.

    Returns
    -------
    df : pandas.core.frame.DataFrame
        DESCRIPTION.

    '''
    df['processed_text'] = df['clean_text'].apply(preprocess_text)
    tfidf_vectorizer = TfidfVectorizer(max_features=100000000)
    X_tfidf = tfidf_vectorizer.fit_transform(df['processed_text'])
    pca = PCA(random_state=42)
    X_reduced = pca.fit_transform(X_tfidf.toarray())  # O usar X_w2v

    # -------------------------------------------------------------------------
    # Crear el modelo
    # -------------------------------------------------------------------------
    hdbscan_clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size,
                                        metric='euclidean',
                                        cluster_selection_method='eom')
    # -------------------------------------------------------------------------
    # Ajustar el modelo a los datos
    # -------------------------------------------------------------------------
    cluster_labels = hdbscan_clusterer.fit_predict(X_reduced)
    # -------------------------------------------------------------------------
    # Obtener las puntuaciones de persistencia de HDBSCAN
    # Estas puntuaciones indican lo "importante" del punto dentro de su clúster
    # (puntos con mayor persistencia están en áreas más densas)
    # -------------------------------------------------------------------------
    unique_labels = np.unique(cluster_labels)
    print("Unique Labels", unique_labels)
    # -------------------------------------------------------------------------
    # Excluyendo el ruido
    # (el ruido suele tener el valor de -1 en cluster_labels)
    # Lista para almacenar los puntos más densos de cada clúster
    # -------------------------------------------------------------------------
    outlier_scores = hdbscan_clusterer.outlier_scores_
    ind = np.array([i for i in range(len(X_reduced))])
    p = []
    for cluster_label in np.unique(unique_labels[unique_labels != -1]):
        # ---------------------------------------------------------------------
        # Filtrar puntos de cada cluster
        # ---------------------------------------------------------------------
        cluster_points_ind = ind[cluster_labels == cluster_label]
        cluster_outlier_scores = outlier_scores[cluster_labels == cluster_label]    
        # ---------------------------------------------------------------------
        # Ordenar puntos del cluster por su puntaje de outlier (menor a mayor)
        # ---------------------------------------------------------------------
        most_dense_points_ind = cluster_points_ind[np.argsort(cluster_outlier_scores)]
        print(cluster_label, most_dense_points_ind)
        p.append(most_dense_points_ind)
    # Evitemos que se gaste innecesariamente
    if len(unique_labels) == 1:
        print("solo tiene uno")
        df['Cluster_Name'] = "Ruido"
        return df
    # -------------------------------------------------------------------------
    # Creacion de string para ChatGPT
    # -------------------------------------------------------------------------
    str_gpt = ""
    for ind, i in enumerate(p):
        str_gpt += str("\nCategoria " + str(ind) + ':\t')
        for indj, j in enumerate(i):
            str_gpt += str(df.iloc[j]['processed_text']+"\n\t  ")
            if indj > 10:
                break

    # -------------------------------------------------------------------------
    # Variable de Open AI
    # -------------------------------------------------------------------------
    os.environ['OPENAI_API_KEY'] = 'sk-proj-BggJh7TJbDYVY1CKL55QT3BlbkFJGbJUrl6H9zcjZvveynde'
    client = OpenAI()
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Eres un asistente que resume y categoriza texto concisamente."},
                {"role": "user", "content":
                f"""Te proporcionaré una lista de categorías con ejemplos de
                 texto en cada una. Deberás agrupar esas categorías en un
                 minimo de {min_cluster}  y no más de {max_cluster} nombres que
                 representen el contenido general de todas ellas, no deben
                 repetirse ninguna categoria ni faltar.la respuesta debe ser
                 unicamente  el nombre de la categoria entre comillas  y entre
                 parentesis las categorias originales que
                  engloba\n\n{str_gpt}"""}
            ],
            max_tokens=200
        )

    except Exception as e:
        print(f"Error al procesar el texto: {e}")
    response.choices[0].message.content
    print("respuesta:\n", response.choices[0].message.content)
    regex = r'"([^"]+)"\s\(([^)]+)\)'
    match = re.findall(regex,
                       response.choices[0].message.content)
    for ind, i in enumerate(match):
        match[ind] = list(match[ind])
        match[ind][1] = np.array(re.findall(r"(\d+)",
                                            i[1]),
                                 dtype=int)
    match.append(["Ruido", np.array([-1])])

    for clus in match:
        print(clus)
    cluster_labels_name = list(cluster_labels)

    for i in range(len(cluster_labels_name)):
        for categorias in match:
            if cluster_labels_name[i] in categorias[1]:
                cluster_labels_name[i] = categorias[0]
    df['Cluster_Name'] = cluster_labels_name
    df = df.drop(columns=['processed_text'], errors='ignore')
    return df


# # se puede ocup get_diff
def get_diff_autor(row, word):
    if isinstance(row['clean_autor'], str):
        li = list(row['clean_autor'].split(" "))
        words_similares = difflib.get_close_matches(word, li, cutoff=0.975)
        if words_similares:
            for palabra in words_similares:
                parentezco = SequenceMatcher(None, palabra, word).ratio()
            return parentezco
        else:
            return 0.0
    else:
        return 0.0


# Limpiar y vectorizar las palabras clave               ok
def etiquetar_autores(row, palabras_clave_vectores):
    categorias_detectadas = []
    palabras = row['clean_autor'].split()
    for palabra in palabras:
        doc = nlp(palabra)
        if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
            # print(f"Palabra sin vector: {palabra}")  # Opcional
            continue
        for categoria, vectores in palabras_clave_vectores.items():
            for palabra_clave, palabra_vector in vectores:
                if palabra_vector is not None:
                    similitud = np.dot(doc.vector, palabra_vector) / (np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector))
                    if similitud > 0.8:
                        categorias_detectadas.append(categoria)
                        break
                else:
                    if get_diff_autor(row, palabra_clave) > 0.8:
                        categorias_detectadas.append(categoria)
                        break
    return ", ".join(set(categorias_detectadas)) if categorias_detectadas else "No Match"


def etiquetar_texto(row, palabras_clave_vectores):
    categorias_detectadas = []
    articulos = ["el",
                 "los",
                 "la",
                 "las",
                 "del",
                 "al",
                 "un",
                 "unos",
                 "una",
                 "unas"]
    palabras = list(set(articulos + preprocess_text(row['clean_text']).split()))[len(articulos)-1:]
    for palabra in palabras:
        doc = nlp(palabra)
        if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
            # print(f"Palabra sin vector: {palabra}")  # Opcional
            continue
        for categoria, vectores in palabras_clave_vectores.items():
            for palabra_clave, palabra_vector in vectores:
                if palabra_vector is not None:
                    similitud = np.dot(doc.vector, palabra_vector) / (np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector))
                    if similitud > 0.8:
                        categorias_detectadas.append(categoria)
                        break
                else:
                    if get_diff_autor(row, palabra_clave) > 0.8:
                        categorias_detectadas.append(categoria)
                        break
    if categorias_detectadas:
        return ", ".join(set(categorias_detectadas))
    else:
        return row['Marca']


# Función para clasificar ejecutivos basándose en 'clean_text'
def etiquetar_ejecutivos(row, palabras_clave_vectores_ejecutivos):
    categorias_detectadas = []
    articulos = ["el",
                 "los",
                 "la",
                 "las",
                 "del",
                 "al",
                 "un",
                 "unos",
                 "una",
                 "unas"]
    palabras = list(set(articulos + preprocess_text(row['clean_text']).split()))[len(articulos)-1:]
    for palabra in palabras:
        doc = nlp(palabra)
        if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
            # print(f"Palabra sin vector: {palabra}")  # Opcional
            continue
        for categoria, vectores in palabras_clave_vectores_ejecutivos.items():
            for palabra_clave, palabra_vector in vectores:
                if palabra_vector is not None:
                    similitud = np.dot(doc.vector, palabra_vector) / (np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector))
                    if similitud > 0.8:
                        categorias_detectadas.append(categoria)
                        break
                else:
                    if get_diff_autor(row, palabra_clave) > 0.8:
                        categorias_detectadas.append(categoria)
                        break
    if categorias_detectadas:
        return ", ".join(set(categorias_detectadas))
    else:
        return "No Match"


def etiquetar_hostiles(row, palabras_clave_vectores_hostiles):
    palabras = row['clean_autor'].split()
    for palabra in palabras:
        doc = nlp(palabra)
        if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
            continue
        for categoria, vectores in palabras_clave_vectores_hostiles.items():
            for palabra_clave, palabra_vector in vectores:
                if palabra_vector is not None:
                    similitud = np.dot(doc.vector, palabra_vector) / (
                        np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector)
                    )
                    if similitud > 0.9:
                        return 'Hostil'
                else:
                    if get_diff_autor(row, palabra_clave) > 0.9:
                        return 'Hostil'
    return 'No Hostil'


def create_run_input(json_file, json_concatenate):
    """ Combina un archivo JSON con un diccionario proporcionado, manejando posibles errores de formato en el JSON.

    Parameters
    ----------
    json_file : str
        Ruta al archivo JSON que se desea cargar.
    json_concatenate : dict
        Diccionario que se combinará con los datos cargados desde el archivo JSON.

    Returns
    -------
    dict
        Un diccionario que combina el contenido del archivo JSON con `json_concatenate`.

    Raises
    ------
    FileNotFoundError
        Si el archivo especificado no existe.
    json.JSONDecodeError
        Si el archivo JSON no tiene un formato válido y no puede ser corregido automáticamente.

    Notes
    -----
    - Si el archivo JSON contiene valores booleanos en formato Python (`True`, `False`) en lugar de su equivalente JSON (`true`, `false`), 
      la función intenta corregirlos automáticamente.
    - Utiliza el operador de unión (`|`) para combinar los dos diccionarios.

    Examples
    --------
    >>> # Archivo JSON válido con contenido {"key1": "value1", "key2": "value2"}
    >>> json_file = "config.json"
    >>> json_concatenate = {"key3": "value3"}
    >>> combined = create_run_input(json_file, json_concatenate)
    >>> print(combined)
    {"key1": "value1", "key2": "value2", "key3": "value3"}
    """
    try:
        with open(json_file, 'r', encoding='utf-8') as archivo_json:
            run_input = json.load(archivo_json)
    except json.JSONDecodeError:
        with open(json_file, 'r') as file:
            json_str = file.read()
        json_str = re.sub(r" False,", " false,", json_str)
        json_str = re.sub(r" True,", " true,", json_str)
        run_input = json.loads(json_str)

    run_input = run_input | json_concatenate
    return run_input


def scrape_facebook(token,
                    config,
                    urls_profile=[],
                    hashtagfb=[],
                    colums_mod={}):
    # Obteniendo Parametros
    onlyPostsNewerThan = datetime.today()+timedelta(days=-config['days_ago'])
    onlyPostsNewerThan = (onlyPostsNewerThan).strftime("%Y-%m-%d")
    onlyPostsOlderThan = datetime.now().strftime("%Y-%m-%d")
    process = config['facebook']['process']
    
    numresultsFB = config['facebook']['facebook_post']['num_url']
    numresultscommentsFB = config['facebook']['facebook_post']['num_comment']
    number_hashtagFB = config['facebook']['facebook_hashtag']['lim']

    # FACEBOOK POST
    col_post = colums_mod['columna_post']
    rename_post = colums_mod['rename_columna_post']
    # FACEBOOK COMMENT
    col_p_comment = colums_mod['columna_comment']
    rename_p_comment = colums_mod['rename_columna_comment']
    # FACEBOOK HASHTAG
    col_Hashtag = colums_mod['columna_hashtag']
    rename_Hashtag = colums_mod['rename_columna_hashtag']
    # FACEBOOK HASHTAG Cooment
    col_h_comment = colums_mod['columna_comment_h']
    rename_h_comment = colums_mod['rename_columna_comment_h']

    listdataframes = []
    cost_all = {}
    # -------------------------------------------------------------------------
    # Post
    # -------------------------------------------------------------------------
    if 'Post' in process and urls_profile:
        def_post = {'Red': 'Facebook',
                    'Tipo de Mencion': 'Post'}
        log("Ejecutando Facebook Post...")
        t = time.time()
        DfFacePostScraper, cost = FacePostScraper(token,
                                                  urls_profile,
                                                  numresultsFB,
                                                  onlyPostsNewerThan,
                                                  onlyPostsOlderThan)
        
        cost_all['Facebook_post'] = cost
        if (DfFacePostScraper.iloc[0][0] == 'no_items'):
            DfFacePostScraper = pd.DataFrame(columns=col_p_comment)

            listdataframes.append(DfFacePostScraper)
        else:
            # COLUMNAS FACEBOOK
            # ['facebookUrl', 'postId', 'pageName', 'url', 'time', 'timestamp',
            # 'user', 'text', 'likes', 'shares', 'media', 'feedbackId',
            # 'topLevelUrl','facebookId', 'pageAdLibrary', 'inputUrl', 'link']
            if 'comments' not in DfFacePostScraper.columns:
                DfFacePostScraper['comments'] = 0
            else:
                DfFacePostScraper['comments'] = DfFacePostScraper['comments'].fillna(0)
            if 'shares' not in DfFacePostScraper.columns:
                DfFacePostScraper['shares'] = 0
            else:
                DfFacePostScraper['shares'] = DfFacePostScraper['shares'].fillna(0)
            listfacepost = DfFacePostScraper[DfFacePostScraper['comments']>0]['url'].to_list()
            # Definiendo Valores por Default
            for k, i in def_post.items():
                DfFacePostScraper[k] = i
            # Revisando que existan las columnas de interesm, en caso contrario
            # un 0
            for col in col_post:
                if col not in DfFacePostScraper.columns:
                    DfFacePostScraper[col] = 0
                else:
                    DfFacePostScraper[col].fillna(0, inplace=True)
            DfFacePostScraper = DfFacePostScraper[col_post]
            # Realizando el Renam
            for col in rename_post:
                if col not in DfFacePostScraper.columns:
                    DfFacePostScraper[col] = 0
            DfFacePostScraper.rename(columns=rename_post, inplace=True)
            # Extraccion de competidor
            DfFacePostScraper['Competidor']= extraer_competencia_fb(DfFacePostScraper['Link'])
            elapsed = time.time() - t
            log(f'Facebook Post:{elapsed:.5f} Elementos obtenidos{len(DfFacePostScraper)}')
            # -----------------------------------------------------------------
            # Comments in Posts
            # -----------------------------------------------------------------            
            if 'PostComment' in process and  listfacepost:
                def_p_comment = {'Red': 'Facebook',
                                 'Tipo de Mencion': 'Comment',
                                 'Numero de Comentarios': 0,
                                 'shares': 0}
                log("Ejecutando Facebook Comments...")
                t = time.time()
                DfFaceCommentScraper, cost = FaceCommentScraper(token,
                                                                listfacepost,
                                                                numresultscommentsFB)
                # 'facebookUrl', 'commentUrl', 'id', 'feedbackId', 'date',
                # 'text','profileUrl', 'profilePicture', 'profileId',
                # 'profileName','likesCount', 'threadingDepth', 'facebookId',
                # 'postTitle','pageAdLibrary', 'inputUrl'
                cost_all['Facebook_p_comment'] = cost
                # Definiendo Valores por Default
                for k, i in def_p_comment.items():
                    DfFaceCommentScraper[k] = i
                # Revisando que existan las columnas de interesm, en caso
                # contrario un 0
                for col in col_p_comment:
                    if col not in DfFaceCommentScraper.columns:
                        DfFaceCommentScraper[col] = 0
                    else:
                        DfFaceCommentScraper[col].fillna(0, inplace=True)
                DfFaceCommentScraper = DfFaceCommentScraper[col_p_comment]
                # Realizando el Renam
                for col in rename_p_comment:
                    if col not in DfFaceCommentScraper.columns:
                        DfFaceCommentScraper[col] = 0
                DfFaceCommentScraper.rename(columns=rename_p_comment, inplace=True)
                # Extraccion de competidor
                DfFaceCommentScraper['Competidor']= extraer_competencia_fb(DfFaceCommentScraper['Link'])
                listdataframes.append(DfFaceCommentScraper)
                elapsed = time.time() - t
                log(f'Facebook Comment: {elapsed:.5f} Elementos obtenidos:{len(DfFaceCommentScraper)}')
            listdataframes.append(DfFacePostScraper)
            
    else:
        DfFacePostScraper = pd.DataFrame(columns=col_p_comment)
        listdataframes.append(DfFacePostScraper)
    if 'Hashtags' in process and hashtagfb:
        def_Hashtag = {'Red': 'Facebook',
                       'Tipo de Mencion': 'Hashtag'}
        log("Ejecutando Facebook Hashtag...")
        t = time.time()
        DfFaceHashtagScraper, cost = FaceHashtagScraper(token,
                                                        hashtagfb,
                                                        number_hashtagFB)
        # ['id', 'postId', 'feedbackId', 'user', 'date', 'url', 'text',
        #        'attachments', 'likesCount', 'sharesCount', 'viewsCount',
        #        'commentsCount', 'hashtag']
        cost_all['Facebook_hashtag'] = cost
        if (DfFaceHashtagScraper.iloc[0][0] == 'no_items'):
            DfFaceHashtagScraper = pd.DataFrame(columns=col_Hashtag)
            listdataframes.append(DfFaceHashtagScraper)
        else:
            if 'commentsCount' not in DfFaceHashtagScraper.columns:
                DfFaceHashtagScraper['commentsCount'] = 0
            else:
                DfFaceHashtagScraper['commentsCount'] = DfFaceHashtagScraper['commentsCount'].fillna(0)
            if 'sharesCount' not in DfFaceHashtagScraper.columns:
                DfFaceHashtagScraper['sharesCount'] = 0
            else:
                DfFaceHashtagScraper['sharesCount'] = DfFaceHashtagScraper['sharesCount'].fillna(0)
            if 'error' in DfFaceHashtagScraper.columns:
                DfFaceHashtagScraper = DfFaceHashtagScraper[DfFaceHashtagScraper['error'].isnull()]
            ind_comment = DfFaceHashtagScraper['commentsCount'] > 0
            comment_hash = []
            if len(DfFaceHashtagScraper) == 0:
                log("Sin Hashtag")
                DfFaceHashtagScraper = pd.DataFrame(columns=['date', 'Red'])
            else:
                comment_hash = DfFaceHashtagScraper[ind_comment]['url'].to_list()
                # Definiendo Valores por Default
                for k, i in def_Hashtag.items():
                    DfFaceHashtagScraper[k] = i
                # OBTENIENDO AUTOR
                DfFaceHashtagScraper['Autor'] = DfFaceHashtagScraper['user'].apply(lambda x: x.get('name') if isinstance(x, dict) else None)
                # Revisando que existan las columnas de interes, en caso
                # contrario un 0
                for col in col_Hashtag:
                    if col not in DfFaceHashtagScraper.columns:
                        DfFaceHashtagScraper[col] = 0
                    else:
                        DfFaceHashtagScraper[col].fillna(0, inplace=True)
                DfFaceHashtagScraper = DfFaceHashtagScraper[col_Hashtag]
                # Realizando el Renam
                for col in rename_Hashtag:
                    if col not in DfFaceHashtagScraper.columns:
                        DfFaceHashtagScraper[col] = 0
                DfFaceHashtagScraper.rename(columns=rename_Hashtag, inplace=True)
    
                # FALTA EXTRAER COMPETIDOR
                DfFaceHashtagScraper['Competidor'] = ''
                # FALTA EXTRAER COMPETIDOR
                elapsed = time.time() - t
                log(f'Facebook Hastag:{elapsed:.5f} Elementos obtenidos{len(DfFaceHashtagScraper)}')
                # ---------------------------------------------------------------------
                # Comments in Hashtag
                # ---------------------------------------------------------------------
            if 'HashtagComment' in process and comment_hash:
                def_h_comment = {'Red': 'Facebook',
                                 'Tipo de Mencion': 'Comment',
                                 'shares': 0,
                                 'vistas': 0}
                log("Ejecutando Facebook Hashtag Comments...")
                t = time.time()
                DfFaceCommentScraper, cost = FaceCommentScraper(token,
                                                                comment_hash,
                                                                numresultscommentsFB)
                # print(DfFaceCommentScraper)
                # ['facebookUrl', 'commentUrl', 'id', 'feedbackId', 'date',
                #  'text','profileUrl', 'profilePicture', 'profileId',
                #  'profileName','likesCount', 'commentsCount', 'comments',
                #  'threadingDepth','facebookId', 'postTitle', 'inputUrl',
                #  'attachments', 'pageAdLibrary']
                cost_all['Facebook_h_comment'] = cost
                # Definiendo Valores por Default
                for k, i in def_h_comment.items():
                    DfFaceCommentScraper[k] = i
                # Revisando que existan las columnas de interesm, en caso
                # contrario un 0
                for col in col_h_comment:
                    if col not in DfFaceCommentScraper.columns:
                        DfFaceCommentScraper[col] = 0
                    else:
                        DfFaceCommentScraper[col].fillna(0, inplace=True)
                DfFaceCommentScraper = DfFaceCommentScraper[col_h_comment]
                #  Rename
                for col in rename_h_comment:
                    if col not in DfFaceCommentScraper.columns:
                        DfFaceCommentScraper[col] = 0
                DfFaceCommentScraper.rename(columns=rename_h_comment,
                                            inplace=True)
                # Extraccion Competidor
                DfFaceCommentScraper['Competidor']= extraer_competencia_fb(DfFaceCommentScraper['Link'])
                listdataframes.append(DfFaceCommentScraper)
                elapsed = time.time() - t
                log(f'Facebook h Comment: {elapsed:.5f} Elementos obtenidos:{len(DfFaceCommentScraper)}')
            listdataframes.append(DfFaceHashtagScraper)
    else:
        DfFaceHashtagScraper = pd.DataFrame(columns=col_h_comment)
        listdataframes.append(DfFaceHashtagScraper)
    return listdataframes, cost_all


def scrape_tiktok(token,
                  onlyPostsNewerThan,
                  onlyPostsOlderThan,
                  process=['Post',
                           'PostComment',
                           'Hashtags',
                           'HashtagComment'],
                  start_urlsTT=[],
                  numresultsTT=10,
                  numresultscommentsTT=10,
                  numresultsrespTT=10,
                  hashtagtiktok=[],
                  number_hashtagTT=10,
                  urlsearchtitkok=[],
                  number_searchTT=10,
                  columnlist=[]):
    listdataframes = []

    if process:
        log("Ejecutando Titkok...")
        if 'Post' in process:
            log("Ejecutando Titkok Post...")
            t = time.time()
            DfTiktokProfileScraper, listtiktokpost = TiktokProfileScraper(token, start_urlsTT, numresultsTT, onlyPostsNewerThan)
            DfTiktokProfileScraper['Competidor']= extraer_competencia_tt(DfTiktokProfileScraper['Link'])
            listdataframes.append(DfTiktokProfileScraper)
            elapsed = time.time() - t
            log(f'Tiktok Post: {elapsed:.5f}   Elementos obtenidos {len(DfTiktokProfileScraper)}')
            if 'PostComment' in process:
                log("Ejecutando Titkok Comments...")
                t = time.time()
                DfTiktokCommentScraper = TitkokCommentScraper(token, listtiktokpost, numresultscommentsTT, numresultsrespTT)
                listdataframes.append(DfTiktokCommentScraper)
                elapsed = time.time() - t
                log(f'Tiktok Comments: {elapsed:.5f}   Elementos obtenidos {len(DfTiktokCommentScraper)}')
            else:
                DfTiktokCommentScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfTiktokCommentScraper)
        else:
            DfTiktokProfileScraper = pd.DataFrame(columns=columnlist)
            listdataframes.append(DfTiktokProfileScraper)
        
        if 'Hashtags' in process:
            log("Ejecutando Titkok Hashtag...")
            t = time.time()
            DfTitkokHashtagScraper, linkstthashtag = TiktokHashtagScraper(token, hashtagtiktok, number_hashtagTT)
            listdataframes.append(DfTitkokHashtagScraper)
            elapsed = time.time() - t
            log(f'Tiktok hastag: {elapsed:.5f}   Elementos obtenidos {len(DfTitkokHashtagScraper)}')
            if 'HashtagComment' in process:
                log("Ejecutando Titkok Hashtag Comments...")
                t = time.time()
                filtered_links__tt = [link for link in linkstthashtag if not pd.isna(link)]
                DfTiktokHashtagCommentScraper = TitkokCommentScraper(token, 
                                                                     filtered_links__tt, 
                                                                     numresultscommentsTT, 
                                                                     numresultsrespTT)
                
                listdataframes.append(DfTiktokHashtagCommentScraper)
                elapsed = time.time() - t
                log(f'Tiktok Comments: {elapsed:.5f}   Elementos obtenidos {len(DfTiktokHashtagCommentScraper)}')
            else:
                DfTiktokHashtagCommentScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfTiktokHashtagCommentScraper)
        else:
            DfTitkokHashtagScraper = pd.DataFrame(columns=columnlist)
            listdataframes.append(DfTitkokHashtagScraper)
        if 'Search' in process:
            log("Ejecutando Tiktok Search...")
            t = time.time()
            DfTiktokSearchScraper, linkstiktoksearch = TiktokSearchScraper(token, urlsearchtitkok, number_searchTT, onlyPostsNewerThan)
            listdataframes.append(DfTiktokSearchScraper)
            elapsed = time.time() - t
            log(f'Tiktok search: {elapsed:.5f}   Elementos obtenidos {len(DfTiktokSearchScraper)}')
            if 'SearchComment' in process:
                log("Ejecutando Titkok Search Comments...")
                t = time.time()
                DfTiktokSearchCommentScraper = TitkokCommentScraper(token, linkstiktoksearch, numresultscommentsTT, numresultsrespTT)
                listdataframes.append(DfTiktokSearchCommentScraper)
                elapsed = time.time() - t
                log(f'Tiktok Comments: {elapsed:.5f}   Elementos obtenidos {len(DfTiktokSearchCommentScraper)}')
            else:
                DfTiktokSearchCommentScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfTiktokSearchCommentScraper)
        else:
            DfTiktokSearchScraper = pd.DataFrame(columns=columnlist)
            listdataframes.append(DfTiktokSearchScraper)
    return listdataframes



def scrape_instagram(token,
                     onlyPostsNewerThan,
                     onlyPostsOlderThan,
                     process=['Post',
                              'PostComment',
                              'Hashtags',
                              'HashtagComment'],
                     urlprofilestinsta=[],
                     numresultsIG=10,
                     numresultscommentsIG=10,
                     hashtaginsta=[],
                     number_hashtagIG=10,
                     columnlist=[]):
    listdataframes = []
    if process:
        log("Ejecutando Instagram...")
        try:
            if 'Post' in process:
                log("Ejecutando Instagram Post...")
                t = time.time()
                
                DfInstaPostScraper, listinstapost = InstaPostScraper(token,
                                                                     urlprofilestinsta,
                                                                     numresultsIG,
                                                                     onlyPostsNewerThan)

                
                elapsed = time.time() - t
                log(f'''iNSTAGRAM Post: {elapsed:.5f}
                    Elementos obtenidos {len(DfInstaPostScraper)}''')
                if 'PostComment' in process:
                    log("Ejecutando Instagram  Comments...")
                    t = time.time()
                    DfInstaCommentScraper = InstaCommentScraper(token,
                                                                listinstapost,
                                                                numresultscommentsIG)
                    # listdataframes.append(DfInstaCommentScraper)
                    elapsed = time.time() - t
                    log(f'''iNSTAGRAM Comentario: {elapsed:.5f}
                        Elementos obtenidos {len(DfInstaCommentScraper)}''')
                    DfInstaCommentScraper = pd.merge(DfInstaCommentScraper,
                                                     DfInstaPostScraper[['Link', 'ownerFullName']],
                                                     on='Link',
                                                     how='left')
                    
                    
                    
                    DfInstaPostScraper = DfInstaPostScraper.rename(columns={'ownerFullName': 'Competidor'})
                    DfInstaCommentScraper = DfInstaCommentScraper.rename(columns={'ownerFullName': 'Competidor'})
                    
                    listdataframes.append(DfInstaCommentScraper)
                else:
                    DfInstaCommentScraper = pd.DataFrame(columns=columnlist)
                    listdataframes.append(DfInstaCommentScraper)
                listdataframes.append(DfInstaPostScraper)
            else:
                DfInstaPostScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfInstaPostScraper)
        except Exception:
            pass
        try:
            if  'Hashtags' in process:
                log("Ejecutando Instagram Hashtag...")
                t = time.time()
                DfInstaHashtagScraper, linkshashtaginsta = InstaHashtagScraper(token, hashtaginsta, number_hashtagIG)
                listdataframes.append(DfInstaHashtagScraper)
                elapsed = time.time() - t
                log(f'''iNSTAGRAM Hashtag: {elapsed:.5f}
                    Elementos obtenidos {len(DfInstaHashtagScraper)}''')
                if  "HashtagComment" in process:
                    log("Ejecutando Instagram Hashtag Comments...")
                    t = time.time()
                    filtered_links = [link for link in linkshashtaginsta if not link.startswith("https://www.instagram.com/explore")]
                    DfInstaHashtagCommentScraper = InstaCommentScraper(token,
                                                                       filtered_links,
                                                                       numresultscommentsIG)
                    listdataframes.append(DfInstaHashtagCommentScraper)
                    elapsed = time.time() - t
                    log(f'''iNSTAGRAM Comentario: {elapsed:.5f}
                        Elementos obtenidos {len(DfInstaHashtagCommentScraper)}''')
                else:
                    DfInstaHashtagCommentScraper = pd.DataFrame(columns=columnlist)
                    listdataframes.append(DfInstaHashtagCommentScraper)
                    
            else:
                DfInstaHashtagScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfInstaHashtagScraper)    
        except Exception:
            pass
    return listdataframes
     
     

def scrape_linkedin(token,
                    process=[],
                    UrlLinkedIn=[],
                    cookie_user={},
                    numresults_LK = 2,
                    numresultscommentsLK =2,
                    columnlist=[]):
    listdataframes = []
    try:
        if process:
             
            more_cookies = {"deepScrape": True,
                            "limitPerSource": numresults_LK,
                            "maxDelay": 60,
                            "minDelay": 5,
                            "proxy": {
                                "useApifyProxy": True,
                                "apifyProxyGroups": [
                                    "BUYPROXIES63748"
                                    ]
                                },
                            "rawData": False,
                            "urls": UrlLinkedIn}
            cookie = create_run_input(cookie_user, more_cookies)
            log("Ejecutando Linkedin...")
            if 'Searchpost' in process:
                log("Ejecutando Linkedin Post...")
                t = time.time()
                DfLinkePostScraper, LinksScrapLinkedin = ScrapLinkedinSearchProfilesLinks(token,
                                                                                          UrlLinkedIn,
                                                                                          numresults_LK,
                                                                                          cookie)
                
                
                elapsed = time.time() - t
                log(f'''Linkedin Post: {elapsed:.5f}
                    Elementos obtenidos {len(DfLinkePostScraper)}''')
            else:
                DfLinkePostScraper = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfLinkePostScraper)
            if 'PostComment' in process:
                prueba = []
                cont = 0
                for i in DfLinkePostScraper['Comentarios']:
                    for j in i:
                        aux = {'date': '',
                               'Red': 'Linkedin',
                               'Link': '',
                               'text': '',
                               'Autor': '',
                               'Likes': '',
                               'Tipo de Mencion': 'Comment',
                               'Numero de Comentarios': '',
                               'Competidor': ''}
                        aux['date'] = pd.to_datetime(j['time'], unit='ms')
                        aux['Link'] = j["link"]
                        aux['text'] = j['text']
                        cont = cont + 1
                        if 'author' in j.keys():
                            aux['Autor'] = j['author']['firstName'] + j['author']['lastName']
                        elif j['entities']:
                            aux['Autor'] = j['entities'][0]['company']['name']
                        else:
                            aux['Autor'] = 'Anonimo'
                        df = pd.DataFrame(aux, index=[0])
                        prueba.append(df)
                DfLinkeCommentScraper = pd.concat(prueba)
                listdataframes.append(DfLinkeCommentScraper)
            
            DfLinkePostScraper = DfLinkePostScraper.drop(columns=['Comentarios'],
                                                         errors='ignore')
            listdataframes.append(DfLinkePostScraper)
            return listdataframes
    except Exception as e:
        logging.error("Linkedin\t"+str(e))
        print(e)
        DfLinkePostScraper = pd.DataFrame(columns=columnlist)
        listdataframes.append(DfLinkePostScraper)
        return listdataframes



class Bot:
    '''
    Clase para interactuar con un bot de Telegram. Permite enviar mensajes de texto y GIFs a un chat o tópico específico, con manejo de estados y configuración dinámica.

    Attributes
    ----------
    NAME : str
        Nombre del bot.
    TOKEN : str
        Token de autenticación del bot proporcionado por Telegram.
    CHAT_ID : int
        Identificador del chat donde se enviarán los mensajes.
    TOPIC_ID : int
        Identificador del tópico dentro del chat (opcional para chats no organizados por tópicos).
    Gif : list
        Lista de URLs de GIFs configurados para el bot.
    Gif_name : list
        Lista de nombres o claves asociadas a los GIFs.
    url_gif : str
        URL base para enviar GIFs mediante la API de Telegram.
    url_text : str
        URL base para enviar mensajes de texto mediante la API de Telegram.
    STATE : str
        Estado actual del bot (por ejemplo, modo de depuración o producción).
    LIST_STATE : list
        Lista de posibles estados del bot.

    Methods
    -------
    __init__(bot)
        Constructor de la clase. Inicializa el bot con los parámetros proporcionados.
    mensaje_url(text)
        Envía un mensaje de texto al chat o tópico, manejando URLs y estados.
    mensaje(text)
        Envía un mensaje de texto al chat o tópico, manejando el formato y los estados.
    mensaje_gif(text, key)
        Envía un mensaje con un GIF asociado a una clave al chat o tópico.
    '''

    def __init__(self, bot):
        '''
        Inicializa la instancia del bot con los parámetros proporcionados en el diccionario `bot`.

        Parameters
        ----------
        bot : dict
            Diccionario con los parámetros de configuración del bot. Debe incluir las claves:
            - 'NAME': Nombre del bot.
            - 'TOKEN': Token de autenticación.
            - 'CHAT_ID': Identificador del chat.
            - 'TOPIC_ID': Identificador del tópico.
            - 'GIF': Lista de URLs de GIFs.
            - 'GIF_NAME': Lista de nombres asociados a los GIFs.
            - 'STATUS': Estado inicial del bot.
            - 'LIST_STATUS': Lista de posibles estados.
        '''
        self.NAME = bot['NAME']
        self.TOKEN = bot['TOKEN']
        self.CHAT_ID = bot['CHAT_ID']
        self.TOPIC_ID = bot['TOPIC_ID']
        self.Gif = bot['GIF']
        self.Gif_name = bot['GIF_NAME']
        self.url_gif = f'https://api.telegram.org/bot{self.TOKEN}/sendAnimation'
        self.url_text = f'https://api.telegram.org/bot{self.TOKEN}/sendMessage'
        self.STATE = bot['status']
        self.LIST_STATE = bot['LIST_STATUS']
        print(f'GENERANDO {self.NAME}, en modo {self.STATE}')

    def mensaje_url(self, text):
        '''
        Envía un mensaje de texto al chat o tópico especificado, manejando posibles formatos y estados.

        Parameters
        ----------
        text : str
            Texto del mensaje a enviar.
        '''
        if self.STATE == self.LIST_STATE[0]:
            print(text)
        else:
            if self.STATE == self.LIST_STATE[1]:
                text = self.STATE + '   ' + text
            params = {
                'chat_id': self.CHAT_ID,
                'text': text,
                'message_thread_id': self.TOPIC_ID,
                "parse_mode": "HTML"
            }
            response = requests.post(self.url_text, data=params)

            if response.status_code == 200:
                print("Mensaje enviado correctamente al tópico")
            else:
                print(response)
                print("Error al enviar el mensaje")

    def mensaje(self, text):
        '''
        Envía un mensaje de texto al chat o tópico especificado con formato MarkdownV2.

        Parameters
        ----------
        text : str
            Texto del mensaje a enviar. Se ajusta automáticamente para cumplir con el formato MarkdownV2.
        '''
        if self.STATE == self.LIST_STATE[0]:
            print(text)
        else:
            if self.STATE == self.LIST_STATE[1]:
                text = self.STATE + '   ' + text
            text = text.replace("-", "\\-").replace(".", "\\.").replace("(", "\\(").replace(")", "\\)")
            params = {
                'chat_id': self.CHAT_ID,
                'text': text,
                'message_thread_id': self.TOPIC_ID,
                "parse_mode": "MarkdownV2"
            }
            response = requests.get(self.url_text, params=params)

            if response.status_code == 200:
                print("Mensaje enviado correctamente al tópico")
            else:
                print(response)
                print("Error al enviar el mensaje")

    def mensaje_gif(self, text, key):
        '''
        Envía un GIF asociado a una clave, junto con un texto al chat o tópico especificado.

        Parameters
        ----------
        text : str
            Texto que acompañará al GIF.
        key : str
            Clave asociada al GIF en la lista `Gif_name`.

        Returns
        -------
        int
            Devuelve -1 si la clave del GIF no es encontrada.
        '''
        if self.STATE == self.LIST_STATE[0]:
            print(text)
        else:
            try:
                typ = self.Gif_name.index(key)
            except ValueError:
                self.mensaje(text)
                return -1
            if self.STATE == self.LIST_STATE[1]:
                text = self.STATE + '   ' + text

            text = text.replace("-", "\\-").replace(".", "\\.").replace("(", "\\(").replace(")", "\\)")
            GIF_URL = self.Gif[typ]
            params = {
                'chat_id': self.CHAT_ID,
                'animation': GIF_URL,
                'message_thread_id': self.TOPIC_ID,
                'caption': text,
                "parse_mode": "MarkdownV2"
            }
            response = requests.get(self.url_gif, params=params)

            if response.status_code == 200:
                print("GIF enviado correctamente al tópico")
            else:
                print(response)
                print("Error al enviar el GIF:", response.json())


# -----------------------------------------------------------------------------
# Funciones Documentadas
# -----------------------------------------------------------------------------

def Sentimentado(df, TARGET_ENTITIES=[]):
    """
    Procesa un DataFrame para realizar análisis de sentimiento y calcula el 
    NPS basado en los resultados de sentimiento.

    Parameters
    ----------
    df : pandas.core.frame.DataFrame
        DataFrame que contiene columnas necesarias para el análisis, incluyendo 
        'Link' y 'text'.
    TARGET_ENTITIES : list, optional
        Lista de entidades objetivo para el análisis. Se asigna a cada fila 
        en la columna `Target Entities`. El valor predeterminado es una lista vacía.

    Returns
    -------
    pandas.core.frame.DataFrame
        DataFrame actualizado con las siguientes columnas:
        - `Target Entities`: Lista de entidades asignadas.
        - `Link_random`: Combina el enlace con un identificador aleatorio.
        - `GEA_sentiment_str`: Columna que contiene el análisis de sentimiento.
        Además, calcula y registra el NPS basado en los resultados.

    Raises
    ------
    ValueError
        Si el DataFrame no contiene las columnas requeridas ('Link', 'text').

    Notes
    -----
    - El campo `text` se limpia para eliminar números y caracteres no deseados, 
      dejando solo texto procesado.
    - Los datos se dividen en chunks si el DataFrame es muy grande, para 
      optimizar el procesamiento.
    - El NPS (Net Promoter Score) se calcula como:
        (Cantidad de positivos - Cantidad de negativos) / Total de filas.
    - La función `process_chunk` debe estar definida previamente y realizar 
      el procesamiento del chunk de datos.

    Examples
    --------
    >>> data = pd.DataFrame({'Link': ['link1', 'link2'], 'text': ['Texto 1', 'Texto 2']})
    >>> TARGET_ENTITIES = ['Entidad1', 'Entidad2']
    >>> processed_data = Sentimentado(data, TARGET_ENTITIES=TARGET_ENTITIES)
    >>> print(processed_data.head())

    """
    df['Target Entities'] = [TARGET_ENTITIES] * len(df)
    df['Link'] = df['Link'].astype(str)
    df['text'] = df['text'].astype(str)
    df['text'] = df['text'].str.replace(r'(|\d+\.)', '').str.split().agg(" ".join)
    df['random'] = [''.join(random.choice(ascii_letters) for _ in range(10))
                    for _ in range(len(df))]
    df['Link_random'] = df.Link.str.cat(df.random)
    chunk_size = 5000
    if len(df) > chunk_size:
        chunks = [df[i:i + chunk_size] for i in range(0, len(df), chunk_size)]
        processed_chunks = [process_chunk(chunk) for chunk in chunks]
        df = pd.concat(processed_chunks)
    else:
        df = process_chunk(df)
    men_pos = len(df[df['GEA_sentiment_str'] == 'positive'])
    men_neg = len(df[df['GEA_sentiment_str'] == 'negative'])
    nps = (men_pos - men_neg) / len(df)
    log(f'NPS: {nps} ')
    return df


def json_dic(path):
    """
    Carga un archivo JSON desde una ruta especificada y lo convierte en un diccionario de Python.

    Parameters
    ----------
    path : str
        Ruta completa del archivo JSON a cargar.

    Returns
    -------
    dict
        Un diccionario de Python que representa el contenido del archivo JSON.

    Raises
    ------
    FileNotFoundError
        Si el archivo en la ruta especificada no existe.
    json.JSONDecodeError
        Si el contenido del archivo no es un JSON válido.

    Examples
    --------
    >>> # Suponiendo que tenemos un archivo "data.json" con contenido válido
    >>> path = "data.json"
    >>> data = json_dic(path)
    >>> print(data)
    {"clave": "valor", "lista": [1, 2, 3]}

    Notes
    -----
    - El archivo debe estar codificado en UTF-8 para evitar problemas de decodificación.
    - Es útil para cargar configuraciones, datos estructurados u otros formatos JSON.
    """
    with open(path, 'r', encoding='utf-8') as archivo_json:
        d = json.load(archivo_json)
    return d

def Categorizador_NS(df,
                     column_name='clean_text',
                     min_cluster_size=10,
                     max_features_c=100000000) -> pd.core.frame.DataFrame:
    """
    Realiza una clasificación no supervisada sobre un DataFrame utilizando el algoritmo
    HDBSCAN de scikit-learn. El tamaño mínimo de los clusters depende del parámetro
    `min_cluster_size`, y el tamaño máximo de características se controla mediante
    `max_features_c` del TfidfVectorizer.
    
    Parameters
    ----------
    df : pandas.core.frame.DataFrame
        DataFrame con la columna que contiene el texto a clusterizar.
    column_name : str, optional
        Nombre de la columna del DataFrame que se usará como entrada para
        la clusterización. El valor predeterminado es 'clean_text'.
    min_cluster_size : int, optional
        Tamaño mínimo de elementos por cluster. El valor predeterminado es 10.
    max_features_c : int, optional
        Número máximo de características que se tendrán en cuenta al construir
        el vocabulario en TfidfVectorizer, ordenadas por frecuencia. 
        El valor predeterminado es 100000000.
    
    Returns
    -------
    df : pandas.core.frame.DataFrame
        El DataFrame de entrada con una nueva columna llamada `cluster`,
        que contiene las etiquetas asignadas a cada muestra.
    p : list of numpy.ndarray
        Lista donde cada elemento es un arreglo de índices que corresponden
        a los puntos más densos de cada cluster (excluyendo outliers).
    
    Notes
    -----
    - Los outliers serán marcados con la etiqueta `-1` en la columna `cluster`.
    - El texto en la columna especificada se preprocesa con una función llamada 
      `preprocess_text`, que debe estar definida previamente.
    - El algoritmo HDBSCAN usa la métrica euclidiana y el método de selección
      de clusters `eom`.
    
    Examples
    --------
    >>> df = pd.DataFrame({'clean_text': ["texto 1", "texto 2", "texto 3"]})
    >>> df, p = Categorizador_NS(df, min_cluster_size=5)
    >>> print(df['cluster'])
    >>> print(p)
    """
    df['processed_text'] = df['clean_text'].apply(preprocess_text)
    tfidf_vectorizer = TfidfVectorizer(max_features=max_features_c)
    X_tfidf = tfidf_vectorizer.fit_transform(df['processed_text'])
    pca = PCA(random_state=42)
    X_reduced = pca.fit_transform(X_tfidf.toarray())  # O usar X_w2v
    # -------------------------------------------------------------------------
    # Crear el modelo
    # -------------------------------------------------------------------------
    hdbscan_clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size,
                                        metric='euclidean',
                                        cluster_selection_method='eom')
    cluster_labels = hdbscan_clusterer.fit_predict(X_reduced)
    unique_labels = np.unique(cluster_labels)
    # print("Unique Labels", unique_labels)
    outlier_scores = hdbscan_clusterer.outlier_scores_
    ind = np.array([i for i in range(len(X_reduced))])
    p = []
    for cluster_label in np.unique(unique_labels[unique_labels != -1]):
        cluster_points_ind = ind[cluster_labels == cluster_label]
        cluster_outlier_scores = outlier_scores[cluster_labels == cluster_label]    
        most_dense_points_ind = cluster_points_ind[np.argsort(cluster_outlier_scores)]
        # print(cluster_label, most_dense_points_ind)
        p.append(most_dense_points_ind)
    df['cluster']=cluster_labels
    print(df['cluster'].value_counts())
    return df, p

def chat_gpt(df,outlier_class='',msj_send=10,cluster_minimo='uno',cluster_maximo='diez',txt=''):
    '''
    Procesa un DataFrame para resumir y categorizar texto utilizando ChatGPT, 
    asignando nombres a los clusters generados previamente.

    Parameters
    ----------
    df : pandas.core.frame.DataFrame
        DataFrame que contiene los datos procesados, incluyendo una columna
        `processed_text` y otra `cluster` que indica las etiquetas de los clusters.
    outlier_class : list,optional
        Outlier por clase
    msj_send : int, optional
        Número máximo de mensajes por categoría que se incluirán en la consulta a ChatGPT.
        El valor predeterminado es 10.
    cluster_minimo : str, optional
        Nombre o descripción del cluster mínimo. Este valor es simbólico y no afecta
        directamente al procesamiento. El valor predeterminado es 'uno'.
    cluster_maximo : str, optional
        Nombre o descripción del cluster máximo. Similar a `cluster_minimo`,
        este valor es simbólico. El valor predeterminado es 'diez'.
    txt : str, optional
        Texto adicional que se incluirá al inicio de la consulta enviada a ChatGPT.

    Returns
    -------
    df : pandas.core.frame.DataFrame
        DataFrame actualizado con una nueva columna `Cluster_Name`, que contiene los 
        nombres asignados a los clusters según la respuesta de ChatGPT. La columna 
        `processed_text` será eliminada si existe.

    Notes
    -----
    - El acceso a OpenAI requiere una clave API válida almacenada en la variable de 
      entorno `OPENAI_API_KEY`.
    - Los nombres de los clusters se extraen de la respuesta generada por ChatGPT y 
      se asignan a las etiquetas de clusters existentes.
    - Si ocurre un error en la interacción con ChatGPT, se imprime un mensaje de error.

    Examples
    --------
    >>> df = pd.DataFrame({'processed_text': ["texto 1", "texto 2"], 'cluster': [0, 1]})
    >>> df = chat_gpt(df, msj_send=5, txt="Resumen de categorías:")
    >>> print(df.head())

    '''
    # -------------------------------------------------------------------------
    # Creacion de string para ChatGPT
    # -------------------------------------------------------------------------
    p = outlier_class
    str_gpt = ""
    for ind, i in enumerate(p):
        str_gpt += str("\nCategoria " + str(ind) + ':\t')
        for indj, j in enumerate(i):
            str_gpt += str(df.iloc[j]['processed_text']+"\n\t  ")
            if indj > msj_send:
                break

    # -------------------------------------------------------------------------
    # Variable de Open AI
    # -------------------------------------------------------------------------
    os.environ['OPENAI_API_KEY'] = 'sk-proj-BggJh7TJbDYVY1CKL55QT3BlbkFJGbJUrl6H9zcjZvveynde'
    client = OpenAI()
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Eres un asistente que resume y categoriza texto concisamente."},
                {"role": "user", "content":
                f"""{txt}\n{str_gpt}"""}
            ],
            max_tokens=200
        )

    except Exception as e:
        print(f"Error al procesar el texto: {e}")
    response.choices[0].message.content
    print("respuesta:\n", response.choices[0].message.content)
    regex = r'"([^"]+)"\s\(([^)]+)\)'
    match = re.findall(regex,
                       response.choices[0].message.content)
    for ind, i in enumerate(match):
        match[ind] = list(match[ind])
        match[ind][1] = np.array(re.findall(r"(\d+)",
                                            i[1]),
                                 dtype=int)
    match.append(["Ruido", np.array([-1])])
    cluster_labels = df['cluster'].to_list()
    for clus in match:
        print(clus)
    cluster_labels_name = list(cluster_labels)

    for i in range(len(cluster_labels_name)):
        for categorias in match:
            if cluster_labels_name[i] in categorias[1]:
                cluster_labels_name[i] = categorias[0]
    df['Cluster_Name'] = cluster_labels_name
    df = df.drop(columns=['processed_text'], errors='ignore')
    return df


def Categorizador_Lista(df, palabras_perfil, col='Perfil', q=0.5):
    """Esta función itera sobre cada registro del DataFrame y calcula la similitud entre el texto y cada una de las palabras clave. Si la similitud supera el umbral `q`, se asigna la palabra clave correspondiente como categoría al registro. En caso de que ningún perfil supere el umbral, se asigna un valor por defecto (por ejemplo, 'No clasificado').

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame de entrada que contiene el texto a categorizar ("clean_text").
    palabras_perfil : dict
        Lista de palabras clave o perfiles a buscar en el texto.
    col : str, optional
        Nombre de la columna donde se almacenará la categoría asignada. Por defecto: 'Perfil'. The default is 'Perfil'.
    q : float, optional
        Umbral de similitud entre el texto y las palabras clave. Valores entre 0 y 1. The default is 0.5.
        
        Ejemplo
        
        >>> df_cat['clean_text'] = df_cat['Title'].apply(limpiar_texto)
        >>> df2 = Categorizador_Lista(df_cat, palabras_perfil,0.75)

    Returns
    -------
    df : pandas.DataFrame
        DataFrame original con una nueva columna definida en "col" que indica la categoría asignada a cada registro..

    """

    perfil_similitud_template = {}
    for key, item in palabras_perfil.items():
        perfil_similitud_template[key] = dict(zip(item, [np.nan for i in item]))

    palabras_clave_vectores = limpiar_y_vectorizar_palabras_clave(palabras_perfil)
    col_cat = []
    col_key = []
    for row in df['clean_text']:
        palabras = row.split()

        # Generador de Diccionario
        perfil_similitud = perfil_similitud_template.copy()
        for palabra in palabras:
            doc = nlp(palabra)
            if not doc.has_vector or np.linalg.norm(doc.vector) == 0:
                continue
            for categoria, vectores in palabras_clave_vectores.items():
                for palabra_clave, palabra_vector in vectores:
                    if palabra_vector is not None:
                        similitud = np.dot(doc.vector, palabra_vector) / (np.linalg.norm(doc.vector) * np.linalg.norm(palabra_vector))
                        perfil_similitud[categoria][palabra_clave] = similitud
                    else:
                        li = palabras
                        words_similares = difflib.get_close_matches(palabra_clave, li, cutoff=0.975)
                        if words_similares:
                            for palabra in words_similares:
                                parentezco = SequenceMatcher(None,
                                                             palabra,
                                                             palabra_clave).ratio()
                        else:
                            parentezco = 0
                            perfil_similitud[categoria][palabra_clave] = parentezco    
        perfil_similitud_limpio = perfil_similitud.copy()
        for categoria in perfil_similitud.keys():

            perfil_similitud_limpio[categoria] = {}
            for palabra_categoria in perfil_similitud[categoria].keys():
                if perfil_similitud[categoria][palabra_categoria] > q:
                    perfil_similitud_limpio[categoria][palabra_categoria] = perfil_similitud[categoria][palabra_categoria]
                    # perfil_similitud_limpio[categoria].pop(palabra_categoria)

        sum_v = [sum(list(i.values())) for i in perfil_similitud_limpio.values()]
        max_v = max(sum_v)
        if max_v == 0:
            col_cat.append("No Match")
        else:
            ind_max = sum_v.index(max_v)
            col_cat.append(list(palabras_perfil.keys())[ind_max])
        # STR
        s=''
        for k,v in perfil_similitud_limpio.items():
            if v:
                s += k
                for k2,v2 in perfil_similitud_limpio[ k].items():
                    s +="\n  " +k2 +': '+ str(v2)
                s+='\n'
        col_key.append(s)
    df[col] = col_cat
    df[col+'_palabras'] = col_key
    return df

def Perfilador(df,outlier_class='',msj_send=10,text_add='',name_colum='propuesta'):
    '''
    Función para categorizar datos en un DataFrame utilizando información procesada por un modelo GPT.

    Esta función agrupa datos basados en texto procesado y asigna etiquetas de categorías, además de
    generar resúmenes con la ayuda de un modelo GPT. También se procesan los resultados para etiquetar
    datos de outliers y categorías identificadas.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame que contiene la información a procesar. Debe incluir al menos la columna 'processed_text'.
    outlier_class : str, opcional
        Clase de outliers a procesar. Representado como una lista de índices agrupados en clusters.
        Por defecto, está vacío.
    msj_send : int, opcional
        Número máximo de textos a incluir en el mensaje enviado al modelo GPT por cada categoría.
        Valor por defecto: 10.
    text_add : str, opcional
        Texto adicional a enviar al modelo GPT como parte del mensaje. Por defecto, está vacío.
    name_colum : str, opcional
        Nombre de la columna nueva que se creará en el DataFrame con las etiquetas de categorías. 
        Por defecto: 'propuesta'.

    Returns
    -------
    tuple
        Una tupla que contiene:
        - pandas.DataFrame: DataFrame original con una nueva columna que incluye las etiquetas de categorías.
        - str: Respuesta generada por el modelo GPT.

    Raises
    ------
    Exception
        Si ocurre un error al interactuar con el modelo GPT.

    Notes
    -----
    - Es necesario tener configurada la clave de API para OpenAI en la variable de entorno 'OPENAI_API_KEY'.
    - La función utiliza expresiones regulares para extraer categorías y sus respectivos índices de la respuesta
      del modelo GPT.
    - La función utiliza el modelo `gpt-4` de OpenAI para generar las categorizaciones.

    Example
    -------
    >>> df = pd.DataFrame({'processed_text': ['texto1', 'texto2'], 'cluster': [0, 1]})
    >>> outlier_class = [[0, 1], [2]]
    >>> df, response = Perfilador(df, outlier_class=outlier_class, msj_send=5, text_add='Resumen: ')
    >>> print(df)
       processed_text  cluster    propuesta
    0          texto1        0  Categoria_0
    1          texto2        1  Categoria_1
    '''
    p = outlier_class
    str_gpt = ""
    
    for ind, i in enumerate(p):
        
        str_lis=[]
        for indj, j in enumerate(i):
            # str_gpt += str(df.iloc[j]['processed_text']+"\n\t  ")
            str_lis.append(df.iloc[j]['processed_text'])
            # if indj > 10:
                # break
        str_gpt += str("\nCategoria "+str(ind)+':\t') + str(list(set(str_lis))[:msj_send])
    #%
    os.environ['OPENAI_API_KEY'] = 'sk-proj-BggJh7TJbDYVY1CKL55QT3BlbkFJGbJUrl6H9zcjZvveynde'
    # Crear el cliente usando la variable de entorno
    
    client = OpenAI()
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Eres un asistente que resume y categoriza texto concisamente."},
                {"role": "user", "content": 
                f"{text_add}{str_gpt}"}
            ],
            max_tokens=600
        )
    except Exception as e:
        print(f"Error al procesar el texto: {e}")
    response.choices[0].message.content
    print("respuesta:\n",response.choices[0].message.content)
    regex = r'"([^"]+)"\s\(([^)]+)\)'
    match = re.findall(regex, response.choices[0].message.content)
    for ind,i in enumerate(match):
        match[ind] = list(match[ind])
        match[ind][1] = np.array(re.findall(r"(\d+)", i[1]),dtype = int)
    match.append(["Ruido",np.array([-1])])
    print("\n")
    for clus in match:
        print(clus)
        
    cluster_labels_name = list(cluster_labels)

    for i in range(len(cluster_labels_name)):
        for categorias in match:
            if cluster_labels_name[i] in categorias[1]:
                cluster_labels_name[i] = categorias[0]
    df[name_colum] = cluster_labels_name
    
    # df = df.drop(columns=['processed_text'] , errors = 'ignore')
    return df , response.choices[0].message.content