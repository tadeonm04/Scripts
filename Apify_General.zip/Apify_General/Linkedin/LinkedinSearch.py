from apify_client import ApifyClient
import pandas as pd
from datetime import datetime, timezone
from numpy import int64


def ScrapLinkedinSearchProfilesLinks(token, urls, numresults, cookie):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    # Prepare the Actor input
    config_post = {
        "deepScrape": True,
        "limitPerSource": numresults,
        "maxDelay": 60,
        "minDelay": 5,
        "proxy": {
            "useApifyProxy": True,
            "apifyProxyGroups": [
                "BUYPROXIES63748"
                ]
            },
        "rawData": False,
        "urls": urls
    }
    run_input = cookie | config_post
    # Run the Actor and wait for it to finish
    run = client.actor("kfiWbq3boy3dWKbiL").call(run_input=run_input)

    dataprofilelinkedin = []
    # Fetch and print Actor results from the run's dataset (if there are any)
    for item in client.dataset(run["defaultDatasetId"]).iterate_items():
        dataprofilelinkedin.append(item)

    dataprofilelinkedin = pd.DataFrame(dataprofilelinkedin)
    # print(dataprofilelinkedin.columns)
    dataprofilelinkedin['urlpost'] = dataprofilelinkedin['shareUrn'].apply(lambda x: "https://www.linkedin.com/feed/update/" + x)
    dataprofilelinkedin['Red'] = 'Linkedin'
    dataprofilelinkedin['Tipo de Mencion'] = 'Post'

    cols = ['postedAtISO',
            'Red',
            'urlpost',
            'text',
            'authorName',
            'numLikes',
            'Tipo de Mencion',
            'numComments',
            'comments',
            'numImpressions',
            'numShares',
            'shareAudience'
                                                ]    
    columnas_existentes = [col for col in cols if col in dataprofilelinkedin.columns]

    dataprofilelinkedin2 = dataprofilelinkedin[columnas_existentes]
    new_column_names = {
        'postedAtISO': 'date',
        'urlpost': 'Link',
        'numLikes': 'Likes',
        'authorName': 'Autor',
        'numComments': 'Numero de Comentarios',
        "comments":"Comentarios",
        "numImpressions":"Impresiones",
        'numShares':"shares",
        "shareAudience":"ShareAudience",
    }
    nombres_existentes = {col: new_name for col, new_name in new_column_names.items() if col in dataprofilelinkedin.columns}
    dataprofilelinkedin2.rename(columns=nombres_existentes, inplace=True)
    # Lista URLS Linekdin para comments
    listLKpost = dataprofilelinkedin['urlpost'].to_list()
    return dataprofilelinkedin2, listLKpost


def convertepochUTC(epoch_time):
    # Convertir epoch a UTC
    try:
        utc_time = datetime.fromtimestamp(epoch_time, tz=timezone.utc)
    except OSError:
        # ERROR EN WINDOWS
        utc_time = datetime.fromtimestamp(epoch_time/1000, tz=timezone.utc)
    # new_utc_time = utc_time.strftime('%Y-%m-%d %H:%M:%S %Z')
    return utc_time


def ScrapLinkedinComments(token, urls, numresults, cookie):
    print("V4")
    new_column_names = {
        'time': 'date',
        'link': 'Link',
        'numLikes': 'Likes',
        'author': 'Autor',
        'numComments': 'Numero de Comentarios'
    }
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    urlscomments = urls
    datacommentslinkedin = []
    cookies = {'cookies': cookie['cookie']}
    for url in urlscomments:
        # Prepare the Actor input
        config_comment = {
            "count": numresults,
            "postUrl": url,
            "proxy": {
                "useApifyProxy": True,
                "apifyProxyGroups": [],
                "apifyProxyCountry": "US"
                },
            "sortType": "RELEVANCE",
            "startPage": 1,
            "minDelay": 2,
            "maxDelay": 7
        }
        # Run the Actor and wait for it to finish
        run_input = cookies | config_comment
        run = client.actor("8xICdc1375BbZdgE3").call(run_input=run_input)

        datacomment = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datacomment.append(item)
        datacomment = pd.DataFrame(datacomment)
        datacommentslinkedin.append(datacomment)
    datafinalcommentsLK = pd.concat(datacommentslinkedin, ignore_index=True)

    if datafinalcommentsLK.empty:
        return pd.DataFrame(columns=new_column_names)

    datafinalcommentsLK['time'] = datafinalcommentsLK['time'].astype(int64)
    datafinalcommentsLK['time'] = datafinalcommentsLK['time'].apply(lambda x: convertepochUTC(x))
    datafinalcommentsLK['Red'] = 'Linkedin'
    datafinalcommentsLK['numLikes'] = ''
    datafinalcommentsLK['Tipo de Mencion'] = 'Comment'
    datafinalcommentsLK['numComments'] = ''
    datafinalcommentsLK2 = datafinalcommentsLK[['time',
                                                'Red',
                                                'link',
                                                'text',
                                                'author',
                                                'numLikes',
                                                'Tipo de Mencion',
                                                'numComments']]
    datafinalcommentsLK2.rename(columns=new_column_names, inplace=True)
    return datafinalcommentsLK2
