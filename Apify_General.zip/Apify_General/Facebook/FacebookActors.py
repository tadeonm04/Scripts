from apify_client import ApifyClient
import pandas as pd

# Initialize the ApifyClient with your API token
def FacePostScraper(token, urlpost, numresults, onlyPostsNewerThan, onlyPostsOlderThan):
    client = ApifyClient(token)

    # Prepare the Actor input
    run_input = {
        "onlyPostsNewerThan": onlyPostsNewerThan,
        "onlyPostsOlderThan": onlyPostsOlderThan,
        "startUrls": urlpost,
        "resultsLimit": numresults,
    }

    # Run the Actor and wait for it to finish
    run = client.actor("KoJrdxJCTtpon81KY").call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    datatotalface = []
    for item in client.dataset("eFUR0Hl0mDLSJR4ei").iterate_items():
        datatotalface.append(item)

    df_facepost = pd.DataFrame(datatotalface)
    results = len(df_facepost)
    print(f'Numero de resultados PostScraper Facebook: {results}')
    try:
        
        cost = run['usageTotalUsd']
        
    except Exception:
        print("Error en el costo de facebook post")
        cost = 0
    return df_facepost, cost
    # try:    
    #     df_facepost = df_facepost.sort_values(by='comments', ascending=False)
    # except KeyError:
    #     print("Error en comentarios")
    # listfacepost = df_facepost['url'].to_list()
    # #numcomments = int(len(listfacepost)/2)
    # #listfacepost = listfacepost[:numcomments]
    
    # #Limpieza y Ajuste Data
    # df_facepost['Red'] = 'Facebook'
    # df_facepost['Tipo de Mencion'] = 'Post'
    # cols = ['time',
    #         'Red',
    #         'url',
    #         'text',
    #         'pageName',
    #         'likes',
    #         'Tipo de Mencion',
    #         'comments']
    # columnas_existentes = [col for col in cols if col in df_facepost.columns]
    # df_facepost2 = df_facepost[columnas_existentes]
    
    # new_column_names = {
    #     'url': 'Link',
    #     'pageName': 'Autor',
    #     'likes': 'Likes',
    #     'comments': 'Numero de Comentarios',
    #     'time': 'date'
    # }
    # nombres_existentes = {col: new_name for col, new_name in new_column_names.items() if col in df_facepost.columns}
    # # Renombrar las columnas
    # df_facepost2.rename(columns=nombres_existentes, inplace=True)
    # # print(df_facepost2.head())
    # return df_facepost2, listfacepost

def FaceCommentScraper(token, linkpost, numresults):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    start_urls = [
        {"url": link}
        for link in linkpost
    ]
    # Prepare the Actor input
    run_input = {
        "startUrls":start_urls,
        "resultsLimit": numresults,
        "includeNestedComments": False,
        "viewOption": "RANKED_UNFILTERED",
    }

    # Run the Actor and wait for it to finish
    run = client.actor("us5srxAYnsrkgUv2v").call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    datatotalface = []
    for item in client.dataset(run["defaultDatasetId"]).iterate_items():
        datatotalface.append(item)

    df_facecomment = pd.DataFrame(datatotalface)
    results = len(df_facecomment)
    print(f'Numero de resultados CommentScraper Facebook: {results}')
    try:
        cost = run['usageTotalUsd']
    except Exception:
        cost = 0
    return df_facecomment, cost
    # #Ajuste y limpieza Data
    # df_facecomment['Red'] = 'Facebook'
    # df_facecomment['Tipo de Mencion'] = 'Comment'
    # df_facecomment['Numero de Comentarios'] = ''

    # df_facecomment2 = df_facecomment[['date','Red', 'facebookUrl', 'text', 'profileName', 'likesCount', 'Tipo de Mencion', 'Numero de Comentarios']]

    # new_column_names = {
    #     'facebookUrl': 'Link',
    #     'profileName': 'Autor',
    #     'likesCount': 'Likes'
    # }

    # # Renombrar las columnas
    # df_facecomment2.rename(columns=new_column_names, inplace=True)
    # return df_facecomment2

def FaceHashtagScraper(token, hashtags, resultslimit):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)

    # Prepare the Actor input
    run_input = {
        "keywordList": hashtags,
        "resultsLimit": resultslimit,
    }

    # Run the Actor and wait for it to finish
    run = client.actor("qgl7gVMdjLUUrMI5P").call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    datatotalface = []
    for item in client.dataset(run["defaultDatasetId"]).iterate_items():
        datatotalface.append(item)

    df_facehashtag = pd.DataFrame(datatotalface)
    results = len(df_facehashtag)
    print(f'Numero de resultados HashtagScraper Facebook: {results}')
    try:
        cost = run['usageTotalUsd']
    except Exception:
        cost = 0
    return df_facehashtag, cost



    df_facehashtag['Red'] = 'Facebook'
    df_facehashtag['Tipo de Mencion'] = 'Hashtag'

    #df_facehashtag2 = df_facehashtag[['date', 'url', 'likesCount', 'shareCount', 'viewsCount', 'commentsCount', 'hashtag', 'text']]
    print("llego aqui")
    print(df_facehashtag)
    df_facehashtag2 = df_facehashtag[['date','Red', 'url', 'text', 'hashtag', 'likesCount', 'Tipo de Mencion', 'commentsCount']]

    new_column_names = {
        'url': 'Link',
        'hashtag': 'Autor',
        'likesCount':'Likes',
        'commentsCount': 'Numero de Comentarios'
    }
    
    # Renombrar las columnas
    df_facehashtag2.rename(columns=new_column_names, inplace=True)
    linksfbht = df_facehashtag2['Link'].to_list()
    
    return df_facehashtag2, linksfbht