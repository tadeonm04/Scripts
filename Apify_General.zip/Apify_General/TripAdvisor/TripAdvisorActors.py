import pandas as pd
from apify_client import ApifyClient

def TripAdvisorScraperLinks(token, maxItemsPerQuery, urlstripad):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    # Prepare the Actor input
    run_input = {
    "currency": "USD",
    "includeAiReviewsSummary": False,
    "includeAttractions": True,
    "includeHotels": True,
    "includeNearbyResults": False,
    "includePriceOffers": True,
    "includeRestaurants": True,
    "includeTags": True,
    "includeVacationRentals": True,
    "maxItemsPerQuery": maxItemsPerQuery,
    "startUrls":urlstripad,
    "checkInDate": "",
    "checkOutDate": "",
    "language": "en"
    }
    datatripadvisor = []
    # Run the Actor and wait for it to finish
    run = client.actor("dbEyMBriog95Fv8CW").call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    for item in client.dataset(run["defaultDatasetId"]).iterate_items():
        datatripadvisor.append(item)

    datascraptripadvisor = pd.DataFrame(datatripadvisor)

    linkstripadvisor = datascraptripadvisor['webUrl'].dropna().to_list()
    datascraptripadvisor['Red'] = 'TripAdvisor'
    datascraptripadvisor['Likes'] = ''
    datascraptripadvisor['Tipo de Mencion'] = 'Post'
    datascraptripadvisor2 = datascraptripadvisor[['Red', 'webUrl', 'description', 'name', 'Likes', 'Tipo de Mencion', 'numberOfReviews']]
    # datascraptripadvisor2 = datascraptripadvisor[['checkInDate', 'Red', 'webUrl', 'description', 'name', 'Likes', 'Tipo de Mencion', 'numberOfReviews']]

    # new_column_names = {
    #     'checkInDate': 'date',
    #     'webUrl ': 'Link',
    #     'description': 'text',  
    #     'numberOfReviews': 'Numero de Comentarios',
    #     'name': 'Autor'
    # }
    new_column_names = {
        'webUrl ': 'Link',
        'description': 'text',  
        'numberOfReviews': 'Numero de Comentarios',
        'name': 'Autor'
    }
    columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
    datascraptripadvisor2.rename(columns=new_column_names, inplace=True)
    datascraptripadvisor2
    return datascraptripadvisor2, linkstripadvisor

def TripAdvisorScraperSites(token, maxItemsPerQuery, listsites):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    datatotaltripadvisor = []
    for site in listsites:
        # Prepare the Actor input
        run_input = {
            "locationFullName": site,
            "maxItemsPerQuery": maxItemsPerQuery,
            "includeTags": True,
            "includeNearbyResults": False,
            "includeAttractions": True,
            "includeRestaurants": True,
            "includeHotels": True,
            "includeVacationRentals": False,
            "checkInDate": "",
            "checkOutDate": "",
            "includePriceOffers": False,
            "includeAiReviewsSummary": False,
            "language": "en",
            "currency": "USD",
        }

        datatripadvisor = []
        # Run the Actor and wait for it to finish
        run = client.actor("dbEyMBriog95Fv8CW").call(run_input=run_input)

        # Fetch and print Actor results from the run's dataset (if there are any)
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatripadvisor.append(item)
        datatripadvisor = pd.DataFrame(datatripadvisor)
        datatotaltripadvisor.append(datatripadvisor)

    datafinaltripadvisor = pd.concat(datatotaltripadvisor, ignore_index=True)
    linkstripadvisor = datafinaltripadvisor['webUrl'].dropna().to_list()

    datafinaltripadvisor['Red'] = 'TripAdvisor'
    datafinaltripadvisor['Likes'] = ''
    datafinaltripadvisor['Tipo de Mencion'] = 'Post'
    datafinaltripadvisor2 = datafinaltripadvisor[['checkInDate', 'Red', 'webUrl', 'description', 'name', 'Likes', 'Tipo de Mencion', 'numberOfReviews']]

    new_column_names = {
        'checkInDate': 'date',
        'webUrl ': 'Link',
        'description': 'text',  
        'numberOfReviews': 'Numero de Comentarios',
        'name': 'Autor'
    }
    columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
    datafinaltripadvisor2.rename(columns=new_column_names, inplace=True)
    return datafinaltripadvisor2, linkstripadvisor

def TripadvisorReviewsScraper(token, maxItemsPerQuery, linkstripad):
    # Initialize the ApifyClient with your API token
    client = ApifyClient(token)
    #maxItemsPerQuery = 3
    # Prepare the Actor input
    run_input = {
        "maxItemsPerQuery": maxItemsPerQuery,
        "reviewRatings": [
            "ALL_REVIEW_RATINGS"
        ],
        "scrapeReviewerInfo": True,
        "startUrls": linkstripad,
        "lastReviewDate": "",
        "reviewsLanguages": [
            "ALL_REVIEW_LANGUAGES"
        ]
        }
    datareviewtrippadvisor = []
    # Run the Actor and wait for it to finish
    run = client.actor("Hvp4YfFGyLM635Q2F").call(run_input=run_input)

    # Fetch and print Actor results from the run's dataset (if there are any)
    for item in client.dataset(run["defaultDatasetId"]).iterate_items():
        datareviewtrippadvisor.append(item)

    datalinktripadvisortotalreview = pd.DataFrame(datareviewtrippadvisor)

    datalinktripadvisortotalreview['Red'] = 'TripAdvisor'
    datalinktripadvisortotalreview['Likes'] = ''
    datalinktripadvisortotalreview['Tipo de Mencion'] = 'Review'
    datalinktripadvisortotalreview['Numero de Comentarios'] = ''
    datalinktripadvisortotalreview2 = datalinktripadvisortotalreview[['publishedDate', 'Red', 'url', 'text', 'user', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']]

    new_column_names = {
        'publishedDate': 'date',
        'url': 'Link',
        'description': 'text',  
        'numberOfReviews': 'Numero de Comentarios',
        'user': 'Autor'
    }
    columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
    datalinktripadvisortotalreview2.rename(columns=new_column_names, inplace=True)
    datalinktripadvisortotalreview2

    return datalinktripadvisortotalreview2