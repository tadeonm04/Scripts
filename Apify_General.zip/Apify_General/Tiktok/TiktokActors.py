from apify_client import ApifyClient
import pandas as pd
import traceback

def TiktokHashtagScraper(token, hashtags, numresults):     
    try:                                     
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = {
            "hashtags": hashtags,
            "resultsPerPage": numresults,
            "searchSection": "",
            "maxProfilesPerQuery": 10,
            "shouldDownloadVideos": False,
            "shouldDownloadCovers": False,
            "shouldDownloadSubtitles": False,
            "shouldDownloadSlideshowImages": False,
            "proxyCountryCode": "None",
        }

        # Run the Actor and wait for it to finish
        run = client.actor("GdWCkxBtKWOsKjdch").call(run_input=run_input)

        datatotaltiktok = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotaltiktok.append(item)

        dftiktokhasg = pd.DataFrame(datatotaltiktok)
        results = len(dftiktokhasg)
        print(f'Numero de resultados HashtagScraper Tiktok: {results}')

        dftiktokhasg['Red'] = 'Tiktok'
        dftiktokhasg['Tipo de Mencion'] = 'Post'

        def extraer_competencia_tt(columna):
            compet = []
            for r in columna:
                try:
                    c = str(r).split('@')[1].split('/')[0]
                except IndexError:  # En caso de que la URL no tenga el formato esperado
                    c = None  # Podrías decidir qué hacer en este caso, aquí simplemente asignamos None
                compet.append(c)
            return compet

        # Aplicar la función a la columna de datos y crear la nueva columna "Autor"
        dftiktokhasg['Autor'] = extraer_competencia_tt(dftiktokhasg['webVideoUrl'])

        dftiktokhasg2 = dftiktokhasg[['createTimeISO', 'Red', 'webVideoUrl', 'text', 'Autor', 'diggCount', 'Tipo de Mencion', 'commentCount']]
        new_column_names = {
            'createTimeISO': 'date',
            'webVideoUrl': 'Link',
            'diggCount': 'Likes',
            'commentCount': 'Numero de Comentarios'
        }
        dftiktokhasg2.rename(columns=new_column_names, inplace=True)
        aux = dftiktokhasg2['Link'].copy()
        
        linkstthashtag = aux.dropna().tolist()
        return dftiktokhasg2, linkstthashtag
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dftiktokhasg2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron post Hashtag')
        traceback.print_exc()
        return dftiktokhasg2

def TitkokCommentScraper(token, urlpost, commentperpost, maxrepliescomment):
    try:
        #Initialize the ApifyClient with your API token
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = {
            "postURLs": urlpost,
            "commentsPerPost": commentperpost,
            "maxRepliesPerComment": maxrepliescomment,
        }

        # Run the Actor and wait for it to finish
        run = client.actor("BDec00yAmCm1QbMEI").call(run_input=run_input)

        datatotaltiktokcomment = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotaltiktokcomment.append(item)

        dftiktokcomments = pd.DataFrame(datatotaltiktokcomment)
        results = len(dftiktokcomments)
        print(f'Numero de resultados CommentScraper Tiktok: {results}')

        dftiktokcomments['Red'] = 'Tiktok'
        dftiktokcomments['Tipo de Mencion'] = 'Comment'
        dftiktokcomments['Numero de Comentarios'] = ''

        dftiktokcomments2 = dftiktokcomments[['createTimeISO', 'Red', 'submittedVideoUrl', 'text', 'uniqueId', 'diggCount', 'Tipo de Mencion', 'Numero de Comentarios']]
        new_column_names = {
            'createTimeISO': 'date',
            'submittedVideoUrl': 'Link',
            'diggCount': 'Likes',
            'uniqueId': 'Autor'
        }
        dftiktokcomments2.rename(columns=new_column_names, inplace=True)
        return dftiktokcomments2
    
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dftiktokcomments2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron comentarios')
        traceback.print_exc()
        return dftiktokcomments2

def TiktokProfileScraper(token, urlprofiles, resultsperpage, oldestPostDate):
    try:
        # Initialize the ApifyClient with your API token
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = {
            "oldestPostDate": oldestPostDate,
            "profiles": urlprofiles,
            "resultsPerPage": resultsperpage,
            "shouldDownloadCovers": False,
            "shouldDownloadSlideshowImages": False,
            "shouldDownloadSubtitles": False,
            "shouldDownloadVideos": False,
            "searchSection": "",
            "maxProfilesPerQuery": 10,
            "proxyCountryCode": "None"
        }
        # Run the Actor and wait for it to finish
        run = client.actor("GdWCkxBtKWOsKjdch").call(run_input=run_input)

        datatotalitiktokscraper = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotalitiktokscraper.append(item)

        dftiktokprofile = pd.DataFrame(datatotalitiktokscraper)
        results = len(dftiktokprofile)
        print(f'Numero de resultados ProfileScraper Tiktok: {results}')

        dftiktokprofile = dftiktokprofile.sort_values(by='commentCount', ascending=False)
        listtiktokpost = dftiktokprofile['webVideoUrl'].to_list()
        numcomments = int(len(listtiktokpost)/2)
        listtiktokpost = listtiktokpost[:numcomments]

        dftiktokprofile['Red'] = 'Tiktok'
        dftiktokprofile['Tipo de Mencion'] = 'Post'
        import ast

        def extraer_competencia_tt(columna):
            compet = []
            for r in columna:
                try:
                    c = str(r).split('@')[1].split('/')[0]
                except IndexError:  # En caso de que la URL no tenga el formato esperado
                    c = None  # Podrías decidir qué hacer en este caso, aquí simplemente asignamos None
                compet.append(c)
            return compet

        # Aplicar la función a la columna de datos y crear la nueva columna "Autor"
        dftiktokprofile['Autor'] = extraer_competencia_tt(dftiktokprofile['webVideoUrl'])

        dftiktokprofile2 = dftiktokprofile[['createTimeISO', 'Red', 'webVideoUrl', 'text', 'Autor', 'diggCount', 'Tipo de Mencion', 'commentCount']]

        new_column_names = {
            'createTimeISO': 'date',
            'webVideoUrl': 'Link',
            'diggCount': 'Likes',
            'commentCount': 'Numero de Comentarios'
        }
        dftiktokprofile2.rename(columns=new_column_names, inplace=True)

        return dftiktokprofile2, listtiktokpost
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dftiktokprofile2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron post')
        traceback.print_exc()
        return dftiktokprofile2

def TiktokSearchScraper(token, urlinks, resultsperpage, oldestPostDate):
    try:
        # Initialize the ApifyClient with your API token
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = {
        "oldestPostDate": oldestPostDate,
        "resultsPerPage": resultsperpage,
        "searchQueries": urlinks,
        "shouldDownloadCovers": False,
        "shouldDownloadSlideshowImages": False,
        "shouldDownloadSubtitles": False,
        "shouldDownloadVideos": False
        }
        # Run the Actor and wait for it to finish
        run = client.actor("GdWCkxBtKWOsKjdch").call(run_input=run_input)

        datatotalitiktokscraper = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotalitiktokscraper.append(item)

        dftiktoksearch = pd.DataFrame(datatotalitiktokscraper)
        results = len(dftiktoksearch)
        print(f'Numero de resultados ProfileScraper Tiktok: {results}')

        dftiktoksearch['Red'] = 'Tiktok'
        dftiktoksearch['Tipo de Mencion'] = 'Post'
        import ast

        def extraer_competencia_tt(columna):
            compet = []
            for r in columna:
                try:
                    c = str(r).split('@')[1].split('/')[0]
                except IndexError:  # En caso de que la URL no tenga el formato esperado
                    c = None  # Podrías decidir qué hacer en este caso, aquí simplemente asignamos None
                compet.append(c)
            return compet

        # Aplicar la función a la columna de datos y crear la nueva columna "Autor"
        dftiktoksearch['Autor'] = extraer_competencia_tt(dftiktoksearch['webVideoUrl'])

        dftiktokSearch2 = dftiktoksearch[['createTimeISO', 'Red', 'webVideoUrl', 'text', 'Autor', 'diggCount', 'Tipo de Mencion', 'commentCount']]

        new_column_names = {
            'createTimeISO': 'date',
            'webVideoUrl': 'Link',
            'diggCount': 'Likes',
            'commentCount': 'Numero de Comentarios'
        }
        dftiktokSearch2.rename(columns=new_column_names, inplace=True)
        linkstiktoksearch = dftiktokSearch2['Link'].to_list()
        return dftiktokSearch2, linkstiktoksearch
    except Exception as e:
        print(e)  
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dftiktokSearch2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron post')
        traceback.print_exc()
        return dftiktokSearch2