# -----------------------------------------------------------------------------
# Librerias Generales
# -----------------------------------------------------------------------------
import os
import time
from datetime import datetime, timedelta
import pandas as pd
import warnings
import numpy as np
# -----------------------------------------------------------------------------
# Utils
# -----------------------------------------------------------------------------
from utils import log
# from utils import limpiar_texto
# from utils import limpiar_y_vectorizar_palabras_clave
# from utils import clasificar_texto
from utils import Categorizador
from utils import TraduccionFiltrado
from utils import extraer_fecha
from utils import buscar_dicc
from utils import json_dic
from utils import scrape_facebook
from utils import scrape_instagram
from utils import scrape_linkedin
from utils import scrape_tiktok
from utils import Sentimentado
from utils import Bot
from Analisis.Trendspotting import TrendSpotting
# -----------------------------------------------------------------------------
# Actores
# -----------------------------------------------------------------------------
# Actores FB
# Actores TripAdvisor
from TripAdvisor.TripAdvisorActors import TripAdvisorScraperLinks
from TripAdvisor.TripAdvisorActors import TripAdvisorScraperSites
from TripAdvisor.TripAdvisorActors import TripadvisorReviewsScraper
# from Linkedin.LinkedinSearch import ScrapLinkedinComments
# Actores Youtube
# from Youtube.YoutubeActors import YoutubeScraper
# -----------------------------------------------------------------------------
# Librerias Categorizador
# -----------------------------------------------------------------------------
import spacy
import logging
import argparse
from io import StringIO
from utils import Categorizador_NS_GPT
# -----------------------------------------------------------------------------
# Librerias Google Api
# -----------------------------------------------------------------------------
from GoogleApi.Spread import SearchFolders
from GoogleApi.Spread import DownloadCSV
from GoogleApi.Spread import SearchFileFolder
from GoogleApi.Spread import GetValues
# from GoogleApi.Spread import DeleteID
from GoogleApi.Spread import CreateSpreadsheet
from GoogleApi.Spread import AppendValues
# from GoogleApi.Spread import share_file
# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
warnings.filterwarnings('ignore')


def scrape_tripadvisor(token,
                       process=[],
                       urlstripAd=[],
                       sitesTripAd=[],
                       resultslinkTA=10,
                       resultsSiteTA=10,
                       reviewslinkTA=10,
                       reviewssiteTA=10,
                       columnlist=[]):
    listdataframes = []
    if process:
        log("Ejecutando TripAdvisor...")
        if 'UrlScraping' in process:
            log("Ejecutando TripAdvisor Links...")
            t = time.time()
            DfTripAdviLink, listTripAdLink = TripAdvisorScraperLinks(token,
                                                                     resultslinkTA,
                                                                     urlstripAd)
            # DfTripAdviLink['Competidor']= extraer_competencia_tt(DfTripAdviLink['Link'])
            listdataframes.append(DfTripAdviLink)
            elapsed = time.time() - t
            log(f'TripAdvisor Links: {elapsed:.5f}   Elementos obtenidos {len(DfTripAdviLink)}')
            if 'ReviewScraping' in process:
                log("Ejecutando Review Scraping for TA Link...")
                t = time.time()
                print(listTripAdLink)
                DfTripAdviReviewsLink = TripadvisorReviewsScraper(token, reviewslinkTA, listTripAdLink)
                listdataframes.append(DfTripAdviReviewsLink)
                elapsed = time.time() - t
                log(f'TripAdvisor Reviews Links: {elapsed:.5f}   Elementos obtenidos {len(DfTripAdviReviewsLink)}')
            else:
                DfTripAdviReviewsLink = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfTripAdviReviewsLink)
        else:
            DfTripAdviLink = pd.DataFrame(columns=columnlist)
            listdataframes.append(DfTripAdviLink)

        if 'SiteScraping' in process:
            log("Ejecutando TripAdvisor Sites...")
            t = time.time()
            DfTripAdviSite, listTripAdSite = TripAdvisorScraperSites(token,
                                                                     resultsSiteTA,
                                                                     sitesTripAd)
            # DfTripAdviSite['Competidor']= extraer_competencia_tt(DfTripAdviSite['Link'])
            listdataframes.append(DfTripAdviSite)
            elapsed = time.time() - t
            log(f'TripAdvisor Sites: {elapsed:.5f}   Elementos obtenidos {len(DfTripAdviSite)}')
            if 'ReviewScraping' in process:
                log("Ejecutando Review Scraping for TA Site...")
                t = time.time()
                DfTripAdviReviewsSite = TripadvisorReviewsScraper(token, reviewssiteTA, listTripAdSite)
                listdataframes.append(DfTripAdviReviewsSite)
                elapsed = time.time() - t
                log(f'TripAdvisor Reviews Sites: {elapsed:.5f}   Elementos obtenidos {len(DfTripAdviReviewsSite)}')
            else:
                DfTripAdviReviewsSite = pd.DataFrame(columns=columnlist)
                listdataframes.append(DfTripAdviReviewsSite)
        else:
            DfTripAdviSite = pd.DataFrame(columns=columnlist)
            listdataframes.append(DfTripAdviSite)

#%%
if __name__ == '__main__':
    nlp = spacy.load('es_core_news_sm')
    # -------------------------------------------------------------------------
    # Parametros con ejecucion en linea
    # -------------------------------------------------------------------------

    parser = argparse.ArgumentParser()
    parser.add_argument('--Configuracion',
                        type=str,
                        default='Config.json',
                        help='Archivo JSON de configuracion')
    args = parser.parse_args()
    config_name = args.Configuracion
    # -------------------------------------------------------------------------
    # Parametros con ejecucion debug                                          |
    # -------------------------------------------------------------------------
    # config_name = 'Config.json'
    # -------------------------------------------------------------------------
    # Parametros con ejecucion debug                                          |
    # -------------------------------------------------------------------------
    config = json_dic(config_name)
    bot_telegram = Bot(json_dic(config["bot"]))
    mensaje = '```'
    mensaje = mensaje + f'{config["nombre_proyecto"]}'
    mensaje = mensaje + f' Iniciando :\t{config["nombre_proyecto"]} \n '
    mensaje = mensaje + f'Hora Inicio:\t{datetime.now().strftime("%Y-%m-%d")}'
    mensaje = '```'
    bot_telegram.mensaje_gif(mensaje, 'INICIO')

    # -------------------------------------------------------------------------
    # Configuracion de Input
    # -------------------------------------------------------------------------
    uploaded_file = config['Input']
    # -------------------------------------------------------------------------
    # Configuracion Categorizador
    # -------------------------------------------------------------------------

    keywords_cat = []
    name_cat = []
    for name, cat in zip(config['Nombres_categorias'], config['Categorias']):
        keywords_cat.append(json_dic(cat))
        name_cat.append(name)
    # -------------------------------------------------------------------------
    # Configuracion de Fechas
    # -------------------------------------------------------------------------
    onlyPostsNewerThan = datetime.today()+timedelta(days=-config['days_ago'])
    onlyPostsNewerThan = (onlyPostsNewerThan).strftime("%Y-%m-%d")
    onlyPostsOlderThan = datetime.now().strftime("%Y-%m-%d")
    # -------------------------------------------------------------------------
    # Configuracion de Log
    # -------------------------------------------------------------------------
    log_name = config['Log']
    logging.basicConfig(filename=log_name,
                        encoding='utf-8',
                        format='%(asctime)s %(levelname)s:%(message)s',
                        level=logging.INFO)
    logging.info(f"Configuracion:{args.Configuracion} |{config['Categorias']}")
    token = "apify_api_KAO6slYyP69UJ4GcYF0anZIVMM6sVl2ohvJG"
    try:
        df = pd.read_csv(uploaded_file)
    except Exception as e:
        print(e)
        df = pd.read_excel(uploaded_file)
    # -------------------------------------------------------------------------
    # Configuracion  Google Api
    # -------------------------------------------------------------------------
    key_credential = 'GOOGLE_APPLICATION_CREDENTIALS'
    os.environ[key_credential] = r"beker-socialand-425907de0ba6.json"
    # -------------------------------------------------------------------------
    # Busqueda de Archivos en folder
    # -------------------------------------------------------------------------
    folder_name = config['folder_drive']
    Folders = SearchFolders()
    id_folder = buscar_dicc(Folders, 'name', folder_name)['id']
    id_list = SearchFileFolder(IDFolder=id_folder)
    id_control = buscar_dicc(id_list, 'name', 'Control')['id']
    values = GetValues(id_control, "A:D")["values"]
    idchecked = [i[1] for i in values]
    idnews = [i for i in id_list if not i['id'] in idchecked]
    # -------------------------------------------------------------------------
    # BrandWatch
    # Busqueda de Archivos en folder
    # -------------------------------------------------------------------------
    files_brandwatch = []
    try:
        if idnews:
            for files_news in idnews:
                if files_news['mimeType'] == 'text/csv':
                    file_csv = DownloadCSV(files_news['id'])
                    files_brandwatch.append(file_csv.decode('utf-8'))
    except AttributeError as e:
        logging.error("Error de descarga:\t"+files_news['name']+"\n"+str(e))

    user_name = config['username']
    nombre_proyecto = config['nombre_proyecto']
    TARGET_ENTITIES = config['TARGET_ENTITIES']
    # -------------------------------------------------------------------------
    # Seleccionador de fuentes
    # -------------------------------------------------------------------------
    start_time = time.time()
    listurlface = df['UrlProfilesFacebook'].dropna().tolist()
    start_urlsFB = [{"url": link} for link in listurlface]
    
    
    start_urlsTT = df['UrlProfilesTiktok'].dropna().tolist()
    urlprofilestinsta = df['UrlProfilesInstagram'].dropna().tolist()
    UrlLinkedIn = df['UrlProfilesLinkedIn'].dropna().tolist()
    urlprofilestiktok = df['UrlProfilesTiktok'].dropna().tolist()
    urlsearchtitkok = df['SearchTiktok'].dropna().tolist()
    hashtagfb = df['Hashtag Facebook'].dropna().tolist()
    hashtaginsta = df['Hashtag Instagram'].dropna().tolist()
    hashtagtiktok = df['Hashtag Tiktok'].dropna().tolist()
    listtrip = df["UrlTripAdvisor"].dropna().tolist()
    urlstripAd = [{"url": link, "method": "GET"} for link in listtrip]
    sitesTripAd = df['SearchPerSiteTripAdvisor'].dropna().to_list()
    lFacebook = []
    lTiktok = []
    lInstagram = []
    lLinkedin = []
#%%
    # -------------------------------------------------------------------------
    # Facebook
    # -------------------------------------------------------------------------
    aux = json_dic('Facebook.json')
    lFacebook = scrape_facebook(token,
                                config,
                                urls_profile=start_urlsFB,
                                hashtagfb=hashtagfb,
                                colums_mod=aux)
    #%%
    columnlist = ['date',
                    'Red',
                    'Link',
                    'text',
                    'Autor',
                    'Likes',
                    'Tipo de Mencion',
                    'Numero de Comentarios']
    # -------------------------------------------------------------------------
    # Instagram
    # -------------------------------------------------------------------------
    lInstagram = scrape_instagram(token,
                                    onlyPostsNewerThan,
                                    onlyPostsOlderThan,
                                    process=config['instagram']['process'],
                                    urlprofilestinsta=urlprofilestinsta,
                                    numresultsIG=config['instagram']['instagram_post']['num_url'],
                                    numresultscommentsIG=config['instagram']['instagram_post']['num_comment'],
                                    hashtaginsta=hashtaginsta,
                                    number_hashtagIG=config['instagram']['instagram_hashtag']['lim'],
                                    columnlist=columnlist)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #%%
    # -------------------------------------------------------------------------
    # TikTok
    # -------------------------------------------------------------------------
    
   
    lTiktok = scrape_tiktok(token,
                            onlyPostsNewerThan,
                            onlyPostsOlderThan,
                            process=config['tiktok']['process'],
                            start_urlsTT=start_urlsTT,
                            numresultsTT=config['tiktok']['tiktok_post']['num_url'],
                            numresultscommentsTT=config['tiktok']['tiktok_post']['num_comment'],
                            numresultsrespTT=config['tiktok']['tiktok_post']['max_reply_comment'],
                            hashtagtiktok=hashtagtiktok,
                            number_hashtagTT=config['tiktok']['tiktok_hashtag']['lim'],
                            urlsearchtitkok=urlsearchtitkok,
                            number_searchTT=config['tiktok']['tiktok_search']['lim'],
                            columnlist=columnlist)
    
    
    
    
    
    
    
    # -------------------------------------------------------------------------
    # Linkedin
    # -------------------------------------------------------------------------
    lLinkedin = scrape_linkedin(token,
                                process=config['linkedin']['process'],
                                UrlLinkedIn=UrlLinkedIn,
                                cookie_user=config['Cookies'],
                                numresults_LK=config['linkedin']['search_post']['num_url'],
                                numresultscommentsLK=config['linkedin']['search_post']['num_comment'],
                                columnlist=columnlist)
    # lTripAdvisor = scrape_tripadvisor(token,
    #                                 process=config['tripadvisor']['process'],
    #                                 urlstripAd = urlstripAd,
    #                                 sitesTripAd = sitesTripAd,
    #                                 resultslinkTA = config['tripadvisor']['urlscraping']['maxItemsPerQuery'],
    #                                 resultsSiteTA = config['tripadvisor']['sitescraping']['maxItemsPerQuery'],
    #                                 reviewslinkTA = config['tripadvisor']['urlscraping']['numreviews'],
    #                                 reviewssiteTA = config['tripadvisor']['sitescraping']['numreviews'],
    #                                 columnlist=columnlist)
    # -------------------------------------------------------------------------
    # BrandWatch
    # -------------------------------------------------------------------------
    #%%
    df_bw = pd.DataFrame()
    for csvbuffer in files_brandwatch:
        df_part = pd.read_csv(StringIO(csvbuffer), skiprows=6)
        df_part = df_part.rename(columns={'Author': 'Autor'})
        df_part = df_part.rename(columns={'Full Text': 'text'})
        df_part = df_part.rename(columns={'Date': 'Fecha'})
        df_part = df_part.rename(columns={'Url': 'Link'})
        df_part = df_part.rename(columns={'X Likes': 'Likes'})
        df_part = df_part.rename(columns={'Mentioned Authors': 'Competidor'})
        df_part = df_part.rename(columns={'Thread Entry Type': 'Tipo de Mencion'})
        df_part = df_part.rename(columns={'Content Source Name': 'Red'})
        df_part['Fecha'] = extraer_fecha(df_part['Fecha'])
        # df_bw = df_bw[pd.to_datetime(df_bw['Fecha']) > fecha_limite_bran]
        # Uniendo los Comments
        comments_bw = ['Facebook Comments',
                       'Instagram Comments',
                       'Linkedin Comments',
                       'Reddit Comments',
                       'Tiktok Comments']
        df_part['Numero de Comentarios'] = df_part[comments_bw].sum(axis=1,
                                                                    numeric_only=True)
        df_part['Fecha'] = pd.to_datetime(df_part['Fecha'], utc=True)
        df_bw = pd.concat([df_bw, df_part], ignore_index=True)

    # -------------------------------------------------------------------------
    # Uniendo Df
    # -------------------------------------------------------------------------
    # listdataframes = lFacebook + lTiktok + lInstagram + lLinkedin + lTripAdvisor
    listdataframes = lFacebook[0] + lTiktok + lInstagram + lLinkedin 
    Dfinaltotal = pd.concat(listdataframes, ignore_index=True)
    # -------------------------------------------------------------------------
    # Eliminando Duplicados
    # -------------------------------------------------------------------------
    Dfinaltotal['concatenated_column'] = Dfinaltotal.astype(str).agg(' '.join, axis=1)
    Dfinaltotal = Dfinaltotal.drop_duplicates(subset=['concatenated_column'])
    Dfinaltotal = Dfinaltotal.drop(columns=['concatenated_column'])
    # -------------------------------------------------------------------------
    # Rename a columnas
    # -------------------------------------------------------------------------
    Dfinaltotal = Dfinaltotal.rename(columns={'text_original': 'text'})
    Dfinaltotal = Dfinaltotal.rename(columns={'date': 'Fecha'})
    # -------------------------------------------------------------------------
    # Concatenando BrandWatch
    # -------------------------------------------------------------------------
    comunes = list(set(Dfinaltotal.columns) & set(df_bw.columns))
    if idnews:
        Dfinaltotal = pd.concat([Dfinaltotal, df_bw[comunes]],
                                ignore_index=True)

    # -------------------------------------------------------------------------
    # Ajustando Fechas
    # -------------------------------------------------------------------------
    Dfinaltotal = Dfinaltotal[Dfinaltotal['Fecha'] != 'nan']
    Dfinaltotal['Fecha'] = pd.to_datetime(Dfinaltotal['Fecha'], utc=True)
    #
    # -------------------------------------------------------------------------
    # Filtro de Fecha
    # -------------------------------------------------------------------------
    Dfinaltotal = Dfinaltotal[Dfinaltotal['Fecha'] > onlyPostsNewerThan]
    # -------------------------------------------------------------------------
    # Filtro de Fecha  superior
    # -------------------------------------------------------------------------
    # Dfinaltotal = Dfinaltotal[Dfinaltotal['Fecha'] < (pd.to_datetime('2024-10-01')).strftime("%Y-%m-%d")]
    # -------------------------------------------------------------------------
    # Separando Fecha
    # -------------------------------------------------------------------------
    Dfinaltotal['Hora'] = Dfinaltotal['Fecha'].dt.time
    Dfinaltotal['Fecha'] = Dfinaltotal['Fecha'].dt.date
    if 'Competidor' in Dfinaltotal.columns:
        Dfinaltotal['Autor. Publi. Original'] = Dfinaltotal['Competidor']
    # -------------------------------------------------------------------------
    # Procesamiento de traducción y filtrado por lenguaje
    # -------------------------------------------------------------------------
    t = time.time()
    df = Dfinaltotal.copy()
    df.dropna(subset=['text', 'Link'], inplace=True)
    df = TraduccionFiltrado(df)
    log('Procesando...')
    elapsed = time.time() - t
    log(f'Processo: Traduccion{elapsed:.5f}   Elementos obtenidos {len(df)}')
    # -------------------------------------------------------------------------
    # Sentimentado GEA
    # -------------------------------------------------------------------------
    t = time.time()
    df = Sentimentado(df, TARGET_ENTITIES)
    elapsed = time.time() - t
    log(f'Processo: GEA{elapsed:.5f}   Elementos obtenidos {len(df)}')
    # -------------------------------------------------------------------------
    # Categorizador
    # -------------------------------------------------------------------------
    df_cat = df.copy()
    t = time.time()
    for name, cat in zip(name_cat, keywords_cat):
        df_cat = Categorizador(df_cat,
                               cat,
                               col_input='clean_text',
                               col_output=name,
                               threshold=0.75)
    # -------------------------------------------------------------------------
    #           Trendspotting
    # -------------------------------------------------------------------------
    if config['TrendSpotting']:
        df_trendSpotting = TrendSpotting(df,col_name = name_cat[0],period = 'Y')
    elapsed = time.time() - t
    for name in name_cat:
        log(df_cat[name].value_counts())
        print("__"*15)

    log(f'''Processo: Categorizador{elapsed:.5f}
        Elementos obtenidos {len(df_cat)}''')

    # -------------------------------------------------------------------------
    # Categorizador No supervisado
    # -------------------------------------------------------------------------
    for name in name_cat:
        df_cat_ns = df_cat[df_cat[name] == 'No Match']
        if len(df_cat_ns) > 0:
            t = time.time()
            df_cat_s = df_cat[df_cat[name] != 'No Match']
            min_cluster = int(np.ceil(len(df_cat_ns) / 100)) + 1
            df_cat_ns = Categorizador_NS_GPT(df_cat_ns, min_cluster, 'uno', 'tres')
            df_cat_s['processed_text'] = '  '
            df_cat_s['Cluster_Name'] = '  '
            elapsed = time.time() - t
            df_cat = pd.concat([df_cat_s, df_cat_ns], ignore_index=True)
        # Brak solo para una clase
        break

    # -------------------------------------------------------------------------
    # Limpieza
    # -------------------------------------------------------------------------
    df_cat = df_cat.sort_values(by=["Fecha", "Hora"])
    df_cat = df_cat.drop(columns=['random', 'Link_random',
                                  'GEA_sentiment_score',
                                  'processed_text'
                                  'Autor_x',
                                  'Autor_y'],
                         errors='ignore')
    df_cat = df_cat.rename(columns={'Categoria': 'Categoria_supervizado',
                                    'cluster': 'Categoria_no_supervizado',
                                    'cluster_name':
                                        'nombre_Categoria_no_supervisado'
                                    },
                           errors='ignore')
    df2 = df_cat[['Hora'] + [col for col in df_cat.columns if col != 'Hora']]
    df2 = df2[['Fecha'] + [col for col in df2.columns if col != 'Fecha']]
    # -------------------------------------------------------------------------
    # Almacenamiento Local
    # -------------------------------------------------------------------------
    mes = ["Enero",
           "Febrero",
           "Marzo",
           "Abril",
           "Mayo",
           "Junio",
           "Julio",
           "Agosto",
           "Septiembre",
           "Octubre",
           "Noviembre",
           "Diciembre"]
    str_month = mes[datetime.now().month-1]
    # titlef = "Prueba Octubre  "+datetime.now().strftime("%Y-%m-%d   %H hrs")
    fecha_ejecucion = datetime.now().strftime("%Y-%m-%d %H:%M hrs")
    
    titlef = f'{config["nombre_proyecto"]} {str_month} {datetime.now().strftime("%Y-%m-%d %H hrs")}'
    df2.to_csv(titlef + '.csv', index=False)
    # -------------------------------------------------------------------------
    # COMPARTIR DRIVE
    # -------------------------------------------------------------------------
    id_spread_new = CreateSpreadsheet(title=titlef,
                                      df=df2,
                                      id_parent=id_folder,
                                      tostr=df2.columns)
    # -------------------------------------------------------------------------
    # Modificaion al Control DRIVE
    # -------------------------------------------------------------------------
    if idnews:
        AppendValues(id_control, [['application/vnd.google-apps.spreadsheet',
                                   id_spread_new,
                                   titlef,
                                   'DEEP']])
        for files_news in idnews:
            AppendValues(id_control, [[idnews[0]['mimeType'],
                                       files_news['id'],
                                       idnews[0]['name'],
                                       "Externo"]])
    else:
        AppendValues(id_control, [['application/vnd.google-apps.spreadsheet',
                                   id_spread_new,
                                   titlef,
                                   'DEEP',
                                   'SIN ARCHIVO BRANDWATCH']])

    mensaje = f'```{config['nombre_proyecto']} '''
    mensaje += f'''Terminando Proyecto:\t{config['nombre_proyecto']}\n '''
    mensaje += f'''Hora de Fin:\t{datetime.now().strftime("%Y-%m-%d")}\n '''
    mensaje += f'''Elementos Obtenidos:\t {len(df2)}'''
    mensaje += f'''Elementos Red:\t {df2["Red"].value_counts()}'''
    mensaje += f'''Inversion:\t {lFacebook[1]}\n '''
    mensaje += f'''```'''
    bot_telegram.mensaje_gif(mensaje, 'FIN')
    mensaje = f'''Spread: <a href="https://docs.google.com/spreadsheets/d/{id_spread_new}/">{titlef}</a>'''
    bot_telegram.mensaje_url(mensaje)
    #%%
    # -------------------------------------------------------------------------
    # BigQuery
    # -------------------------------------------------------------------------
    # gbq.to_gbq(df_cat, table, project_id=gcp_project, if_exists='append')
    # -------------------------------------------------------------------------
    # Compartir en Drive
    # -------------------------------------------------------------------------
    # real_user = ['andres.vazquez@llyc.global', 'manuel.solisb@llyc.global']
    # for i in real_user:
    #     share_file(id_spread_new,
    #                i,
    #                role="writer")