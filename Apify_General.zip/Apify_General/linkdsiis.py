# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 02:11:51 2025

@author: manue
"""
from Linkedin.LinkedinSearch import ScrapLinkedinSearchProfilesLinks
from utils import create_run_input

import pandas as pd

marcas = ["ACS",
          ]

#%%
for xxx in range(len(marcas)):
    NMARCA = marcas[xxx]
    
    
    listdataframes = []
                    
    UrlLinkedIn =  ["https://www.linkedin.com/search/results/content/?keywords=GrupoACS",
               "https://www.linkedin.com/search/results/content/?keywords=Grupo%20ACS&origin=GLOBAL_SEARCH_HEADER&s",
               ]
    print(f"{NMARCA}\t{UrlLinkedIn}")
    #%%
    numresults_LK = 500
    token = "apify_api_KAO6slYyP69UJ4GcYF0anZIVMM6sVl2ohvJG"
    #%%
    try:
        
        more_cookies = {"deepScrape": True,
                        "limitPerSource": 500,
                        "maxDelay": 60,
                        "minDelay": 5,
                        "proxy": {
                            "useApifyProxy": True,
                            "apifyProxyGroups": [
                                "BUYPROXIES63748"
                                ]
                            },
                        "rawData": False,
                        "urls": UrlLinkedIn}
        cookie = create_run_input("cookies.json", more_cookies)
        if True:
            DfLinkePostScraper, LinksScrapLinkedin = ScrapLinkedinSearchProfilesLinks(token,
                                                                                      UrlLinkedIn,
                                                                                      numresults_LK,
                                                                                      cookie)
        
        if True:
            prueba = []
            cont = 0
            df_aux = DfLinkePostScraper[DfLinkePostScraper['Numero de Comentarios']>0]
    
            for i in df_aux['Comentarios']:
                for j in i:
                    aux = {'date': '',
                           'Red': 'Linkedin',
                           'Link': '',
                           'text': '',
                           'Autor': '',
                           'Likes': '',
                           'Tipo de Mencion': 'Comment',
                           'Numero de Comentarios': '',
                           'Competidor': ''}
                    aux['date'] = pd.to_datetime(j['time'], unit='ms')
                    aux['Link'] = j["link"]
                    aux['text'] = j['text']
                    cont = cont + 1
                    try:
                        if 'author' in j.keys():
                            aux['Autor'] = j['author']['firstName'] + j['author']['lastName']
                        elif j['entities']:
                            aux['Autor'] = j['entities'][0]['company']['name']
                        else:
                            aux['Autor'] = 'Anonimo'
                        df = pd.DataFrame(aux, index=[0])
                        prueba.append(df)
                    except:
                        pass
            DfLinkeCommentScraper = pd.concat(prueba)
            listdataframes.append(DfLinkeCommentScraper)
        
        DfLinkePostScraper = DfLinkePostScraper.drop(columns=['Comentarios'],
                                                     errors='ignore')
        listdataframes.append(DfLinkePostScraper)
        #%%
    except Exception as e:
        
        print(e)
        
        
    #%%
    df_hashtag = pd.concat(listdataframes,ignore_index=True)
    
    
    df_hashtag['Marca'] =NMARCA
    
    df_hashtag.to_csv(f"LK_{NMARCA}.csv",index=False)
