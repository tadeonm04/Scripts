from apify_client import ApifyClient
import pandas as pd
import traceback

# Initialize the ApifyClient with your API token
def InstaHashtagScraper(token, hashtags, numresults):
    try:
        client = ApifyClient(token)
        # Prepare the Actor input
        run_input = {
            "hashtags": hashtags,
            "resultsLimit": numresults,
        }
        # Run the Actor and wait for it to finish
        print('Ejecutando Instagram Hashtag Scrapper')
        run = client.actor("reGe1ST3OBgYZSsZJ").call(run_input=run_input)
        print('Proceso finalizado')

        # Fetch and print Actor results from the run's dataset (if there are any)
        datatotal = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotal.append(item)

        dfinstahashtag = pd.DataFrame(datatotal)
        results = len(dfinstahashtag)
        print(f'Numero de resultados HashtagScraper Instagram: {results}')

        dfinstahashtag['Red'] = 'Instagram'
        dfinstahashtag['Tipo de Mencion'] = 'Post'

        dfinstahashtag2 = dfinstahashtag[['timestamp', 'Red', 'url', 'caption', 'ownerFullName', 'likesCount', 'Tipo de Mencion', 'commentsCount']]
        new_column_names = {
            'timestamp': 'date',
            'url': 'Link',
            'caption': 'text',
            'likesCount': 'Likes',
            'ownerFullName': 'Autor',
            'commentsCount': 'Numero de Comentarios'
        }
        dfinstahashtag2.rename(columns=new_column_names, inplace=True)
        linkshashtaginsta = dfinstahashtag2['Link'].to_list()
        return dfinstahashtag2, linkshashtaginsta
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dfinstahashtag2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron post Hashtag')
        traceback.print_exc()
        return dfinstahashtag2

def InstaPostScraper(token, userslinks, numresults, onlyPostsNewerThanInsta):
    try:
        # Initialize the ApifyClient with your API token
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = { 
            "onlyPostsNewerThan": onlyPostsNewerThanInsta,
            "username": userslinks,
            "resultsLimit": numresults,
        }
        # Run the Actor and wait for it to finish
        print('Ejecutando Instagram Post Scrapper')
        run = client.actor("nH2AHrwxeTRJoN5hX").call(run_input=run_input)
        print('Proceso finalizado')

        # Fetch and print Actor results from the run's dataset (if there are any)
        datatotalinsta = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotalinsta.append(item)

        dfinstapost = pd.DataFrame(datatotalinsta)
        results = len(dfinstapost)
        print(f'Numero de resultados PostScraper Instagram: {results}')
        
        dfinstapost = dfinstapost.sort_values(by='commentsCount', ascending=False)
        listinstapost = dfinstapost['url'].to_list()
        numcomments = int(len(listinstapost)/2)
        listinstapost = listinstapost[:numcomments]

        dfinstapost['Red'] = 'Instagram'
        dfinstapost['Tipo de Mencion'] = 'Post'

        dfinstapost2 = dfinstapost[['timestamp',
                                    'Red',
                                    'url', 
                                    'caption', 
                                    'ownerUsername',
                                    'ownerFullName', 
                                    'likesCount', 
                                    'Tipo de Mencion', 
                                    'commentsCount']]
        new_column_names = {
            'timestamp': 'date',
            'url': 'Link',
            'caption': 'text',
            'likesCount': 'Likes',
            'ownerUsername': 'Autor',
            'commentsCount': 'Numero de Comentarios'
        }
        dfinstapost2.rename(columns=new_column_names, inplace=True)

        print(dfinstapost.columns)
        return dfinstapost2, listinstapost
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dfinstapost2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron post')
        traceback.print_exc()
        return dfinstapost2

def InstaCommentScraper(token, linkspost, numresults):
    try:
        # Initialize the ApifyClient with your API token
        client = ApifyClient(token)

        # Prepare the Actor input
        run_input = {
            "directUrls": linkspost,
            "resultsLimit": numresults,
        }
        # Run the Actor and wait for it to finish
        print('Ejecutando Instagram Comments Scrapper')
        run = client.actor("SbK00X0JYCPblD2wp").call(run_input=run_input)
        print('Proceso finalizado')

        datatotalinstacomment = []
        for item in client.dataset(run["defaultDatasetId"]).iterate_items():
            datatotalinstacomment.append(item)

        dfinstacomment = pd.DataFrame(datatotalinstacomment)
        results = len(dfinstacomment)
        print(f'Numero de resultados CommentScraper Instagram: {results}')

        dfinstacomment['Red'] = 'Instagram'
        dfinstacomment['Tipo de Mencion'] = 'Comment'
        dfinstacomment['Numero de Comentarios'] =  ''

        dfinstacomment2 = dfinstacomment[['timestamp', 'Red', 'postUrl', 'text', 'ownerUsername', 'likesCount', 'Tipo de Mencion', 'Numero de Comentarios']]
        new_column_names = {
            'timestamp': 'date',
            'postUrl': 'Link',
            'likesCount': 'Likes',
            'ownerUsername': 'Autor',
        }
        dfinstacomment2.rename(columns=new_column_names, inplace=True)

        return dfinstacomment2
    except Exception as e:
        print(e)
        columnlist = ['date', 'Red', 'Link', 'text', 'Autor', 'Likes', 'Tipo de Mencion', 'Numero de Comentarios']
        dfinstacomment2 = pd.DataFrame(columns=columnlist)
        print('No se capturaron comentarios')
        traceback.print_exc()
        return dfinstacomment2
